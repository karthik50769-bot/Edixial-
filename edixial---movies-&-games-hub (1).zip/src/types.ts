export type MediaType = 'movie' | 'game' | 'series' | 'article';

export interface Movie {
  id: string;
  title: string;
  originalTitle?: string;
  synopsis: string;
  posterUrl: string;
  backdropUrl?: string;
  bannerUrl?: string;
  releaseYear: number;
  duration: string; // e.g. "2h 28m"
  rating: number; // e.g. 8.9 / 10
  genres: string[];
  director: string;
  cast: string[];
  trailerUrl?: string;
  videoUrl?: string;
  language: string;
  status: 'Released' | 'In Theaters' | 'Coming Soon' | 'Rumored';
  ageRating?: string;
  featured?: boolean;
  views?: number;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Game {
  id: string;
  title: string;
  synopsis: string;
  posterUrl: string;
  backdropUrl?: string;
  releaseDate: string; // e.g. "2025" or "Oct 2025"
  developer: string;
  publisher: string;
  platforms: string[]; // e.g. ['PC', 'PS5', 'Xbox Series X', 'Nintendo Switch']
  genres: string[];
  rating: number; // e.g. 9.4
  trailerUrl?: string;
  downloadUrl?: string;
  playUrl?: string;
  screenshots?: string[];
  systemRequirements?: {
    os?: string;
    processor?: string;
    memory?: string;
    graphics?: string;
    storage?: string;
  };
  featured?: boolean;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Series {
  id: string;
  title: string;
  synopsis: string;
  posterUrl: string;
  backdropUrl?: string;
  releaseYear: number;
  totalSeasons: number;
  totalEpisodes: number;
  genres: string[];
  creator: string;
  cast: string[];
  rating: number;
  trailerUrl?: string;
  status: 'Ongoing' | 'Completed' | 'Upcoming' | 'Renewed';
  network?: string; // e.g. "HBO Max", "Netflix", "Disney+"
  featured?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string; // Markdown or rich text
  category: 'News' | 'Review' | 'Feature' | 'Patch Notes' | 'Exclusive' | 'Guide';
  relatedType?: 'movie' | 'game' | 'series' | 'general';
  relatedItemId?: string;
  coverUrl: string;
  author: {
    name: string;
    avatar?: string;
    role: string;
    email?: string;
  };
  publishedAt: string;
  readTime: string; // e.g. "4 min read"
  tags: string[];
  featured?: boolean;
  views?: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: 'owner' | 'super_admin' | 'editor';
  addedAt: string;
  addedBy?: string;
  status: 'active' | 'pending' | 'revoked';
}

export interface AppState {
  movies: Movie[];
  games: Game[];
  series: Series[];
  articles: Article[];
  admins: AdminUser[];
}

export type ActiveTab = 'home' | 'movies' | 'games' | 'series' | 'articles' | 'saved' | 'admin';
export type AdminSubTab = 'overview' | 'movies' | 'games' | 'series' | 'articles' | 'admins' | 'settings' | 'security';

export interface FirebaseDiagnostics {
  projectId: string;
  authDomain: string;
  apiKeyMasked: string;
  currentHost: string;
  isConfigured: boolean;
  hasCustomConfig: boolean;
  lastError: string | null;
  authReady: boolean;
}
