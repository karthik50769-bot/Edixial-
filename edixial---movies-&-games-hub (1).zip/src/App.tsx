import React, { useState, useEffect } from 'react';
import {
  Film,
  Gamepad2,
  Tv,
  Newspaper,
  Bookmark,
  Shield,
  Star,
  Sparkles,
  Search,
  Filter,
  ArrowRight,
  Play,
  SlidersHorizontal,
  Flame,
  Clock,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, checkIsAdmin, OWNER_EMAIL } from './lib/firebase';
import {
  subscribeMovies,
  subscribeGames,
  subscribeSeries,
  subscribeArticles,
  subscribeAdmins,
  initializeFirestoreSync
} from './lib/dataStore';
import { Movie, Game, Series, Article, AdminUser, ActiveTab } from './types';

// Components
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { MediaCard } from './components/MediaCard';
import { DetailModal } from './components/DetailModal';
import { TrailerModal } from './components/TrailerModal';
import { ArticlesSection, ArticleModal } from './components/ArticlesSection';
import { FirebaseDiagnosticsModal } from './components/FirebaseDiagnosticsModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Footer } from './components/Footer';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  
  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Data Collections
  const [movies, setMovies] = useState<Movie[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [series, setSeries] = useState<Series[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [admins, setAdmins] = useState<AdminUser[]>([]);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [genreFilter, setGenreFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'featured' | 'rating' | 'newest'>('featured');

  // Saved / Watchlist Items
  const [savedIds, setSavedIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('edixial_watchlist_ids');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch {
      return new Set();
    }
  });

  // Modals State
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [detailModalItem, setDetailModalItem] = useState<{
    type: 'movie' | 'game' | 'series';
    item: Movie | Game | Series;
  } | null>(null);
  
  const [trailerModalData, setTrailerModalData] = useState<{
    isOpen: boolean;
    url?: string;
    title?: string;
  }>({ isOpen: false });

  const [activeArticleModal, setActiveArticleModal] = useState<Article | null>(null);

  // Preselected item for Admin editing directly from card
  const [preselectedEdit, setPreselectedEdit] = useState<{
    type: 'movie' | 'game' | 'series' | 'article';
    item: any;
  } | null>(null);

  // 1. Initialize Route Check (/admin or #admin)
  useEffect(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (path === '/admin' || hash === '#admin' || hash === '#/admin') {
      setActiveTab('admin');
    }
  }, []);

  // 2. Subscribe to Firebase Auth and check Admin Status
  useEffect(() => {
    if (!auth) {
      setAuthLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const adminStatus = await checkIsAdmin(user);
        setIsAdmin(adminStatus);
        // Requirement: "After the administrator logs in successfully, redirect them to the EDIXIAL Admin Dashboard."
        if (adminStatus) {
          setActiveTab('admin');
        }
      } else {
        setIsAdmin(false);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 3. Initialize Realtime Data Subscriptions & Firestore listeners
  useEffect(() => {
    initializeFirestoreSync();
    const unsubMovies = subscribeMovies(setMovies);
    const unsubGames = subscribeGames(setGames);
    const unsubSeries = subscribeSeries(setSeries);
    const unsubArticles = subscribeArticles(setArticles);
    const unsubAdmins = subscribeAdmins(setAdmins);

    return () => {
      unsubMovies();
      unsubGames();
      unsubSeries();
      unsubArticles();
      unsubAdmins();
    };
  }, []);

  // 4. Toggle Saved Item
  const toggleSave = (id: string) => {
    setSavedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      try {
        localStorage.setItem('edixial_watchlist_ids', JSON.stringify(Array.from(next)));
      } catch {}
      return next;
    });
  };

  // 5. Open Trailer Modal
  const handleOpenTrailer = (url?: string, title?: string) => {
    setTrailerModalData({
      isOpen: true,
      url: url || 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      title
    });
  };

  // 6. Direct Edit from Card in Admin
  const handleEditAdminFromCard = (type: 'movie' | 'game' | 'series', item: any) => {
    setPreselectedEdit({ type, item });
    setActiveTab('admin');
  };

  // Featured Spotlight items for Hero Banner
  const featuredSpotlights = [
    ...movies.filter(m => m.featured).map(m => ({ type: 'movie' as const, data: m })),
    ...games.filter(g => g.featured).map(g => ({ type: 'game' as const, data: g })),
    ...series.filter(s => s.featured).map(s => ({ type: 'series' as const, data: s }))
  ];

  // If no featured flag, fallback to first of each
  const activeSpotlights = featuredSpotlights.length > 0
    ? featuredSpotlights
    : [
        ...(movies[0] ? [{ type: 'movie' as const, data: movies[0] }] : []),
        ...(games[0] ? [{ type: 'game' as const, data: games[0] }] : []),
        ...(series[0] ? [{ type: 'series' as const, data: series[0] }] : [])
      ];

  // Filtering & Sorting
  const filterList = <T extends Movie | Game | Series>(items: T[]): T[] => {
    return items
      .filter((item) => {
        const matchesSearch = !searchQuery ||
          item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.synopsis.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesGenre = genreFilter === 'All' ||
          (item.genres && item.genres.some(g => g.toLowerCase() === genreFilter.toLowerCase()));

        return matchesSearch && matchesGenre;
      })
      .sort((a, b) => {
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'newest') return (b.createdAt || '').localeCompare(a.createdAt || '');
        return 0;
      });
  };

  const filteredMovies = filterList(movies);
  const filteredGames = filterList(games);
  const filteredSeries = filterList(series);

  // Saved items list
  const savedMovies = movies.filter(m => savedIds.has(m.id));
  const savedGames = games.filter(g => savedIds.has(g.id));
  const savedSeriesList = series.filter(s => savedIds.has(s.id));
  const savedArticlesList = articles.filter(a => savedIds.has(a.id));
  const totalSaved = savedMovies.length + savedGames.length + savedSeriesList.length + savedArticlesList.length;

  // Extract unique genres
  const allGenres = Array.from(
    new Set([
      'All',
      ...movies.flatMap(m => m.genres || []),
      ...games.flatMap(g => g.genres || []),
      ...series.flatMap(s => s.genres || [])
    ])
  ).slice(0, 10);

  return (
    <div className="min-h-screen flex flex-col bg-[#080a0f] text-slate-100 selection:bg-amber-500 selection:text-black">
      
      {/* Top Main Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        isAdmin={isAdmin}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        savedCount={totalSaved}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        
        {/* ================= TAB: ADMIN DASHBOARD ================= */}
        {activeTab === 'admin' ? (
          <AdminDashboard
            currentUser={currentUser}
            isAdmin={isAdmin}
            onReturnHome={() => setActiveTab('home')}
            movies={movies}
            games={games}
            series={series}
            articles={articles}
            admins={admins}
            onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
            preselectedEditItem={preselectedEdit}
            onClearPreselectedEdit={() => setPreselectedEdit(null)}
          />
        ) : (
          <div className="space-y-12">
            
            {/* Spotlight Hero Banner on Home */}
            {activeTab === 'home' && !searchQuery && (
              <HeroBanner
                featuredItems={activeSpotlights}
                onSelect={(type, item) => setDetailModalItem({ type, item })}
                onOpenTrailer={handleOpenTrailer}
                savedIds={savedIds}
                onToggleSave={toggleSave}
              />
            )}

            {/* Global Search / Filter Controls bar for catalog views */}
            {(activeTab === 'movies' || activeTab === 'games' || activeTab === 'series') && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-[#0d111b] border border-white/5 rounded-2xl">
                {/* Genres */}
                <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                  <span className="text-xs text-slate-400 font-semibold mr-1 flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5 text-amber-400" /> Genre:
                  </span>
                  {allGenres.map((genre) => (
                    <button
                      key={genre}
                      onClick={() => setGenreFilter(genre)}
                      className={`px-3 py-1 rounded-xl text-xs font-medium transition ${
                        genreFilter === genre
                          ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-500/20'
                          : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      {genre}
                    </button>
                  ))}
                </div>

                {/* Sort Option */}
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
                  <span>Sort By:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="featured">Featured First</option>
                    <option value="rating">Top Rated (★)</option>
                    <option value="newest">Recently Added</option>
                  </select>
                </div>
              </div>
            )}

            {/* ================= TAB: HOME (Multi-Category Portal) ================= */}
            {activeTab === 'home' && (
              <div className="space-y-16">
                
                {/* 1. Blockbuster Movies Section */}
                <section className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
                        <Film className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-xl sm:text-2xl font-black text-white font-['Outfit']">
                          Trending Movies & Premieres
                        </h2>
                        <p className="text-xs text-slate-400">4K Ultra HD blockbusters and award-winning cinema.</p>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('movies')}
                      className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 font-bold transition"
                    >
                      <span>View All Movies ({movies.length})</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                    {movies.slice(0, 5).map((movie) => (
                      <MediaCard
                        key={movie.id}
                        type="movie"
                        item={movie}
                        onSelect={(type, item) => setDetailModalItem({ type, item })}
                        onOpenTrailer={handleOpenTrailer}
                        isSaved={savedIds.has(movie.id)}
                        onToggleSave={toggleSave}
                        isAdmin={isAdmin}
                        onEditAdmin={handleEditAdminFromCard}
                      />
                    ))}
                  </div>
                </section>

                {/* 2. Next-Gen Games Section */}
                <section className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                        <Gamepad2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-xl sm:text-2xl font-black text-white font-['Outfit']">
                          Next-Gen Games & Hits
                        </h2>
                        <p className="text-xs text-slate-400">Unreal Engine 5 titles, ray tracing RPGs, and action epics.</p>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('games')}
                      className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-bold transition"
                    >
                      <span>Explore Games ({games.length})</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                    {games.slice(0, 5).map((game) => (
                      <MediaCard
                        key={game.id}
                        type="game"
                        item={game}
                        onSelect={(type, item) => setDetailModalItem({ type, item })}
                        onOpenTrailer={handleOpenTrailer}
                        isSaved={savedIds.has(game.id)}
                        onToggleSave={toggleSave}
                        isAdmin={isAdmin}
                        onEditAdmin={handleEditAdminFromCard}
                      />
                    ))}
                  </div>
                </section>

                {/* 3. Original Series Section */}
                <section className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl">
                        <Tv className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-xl sm:text-2xl font-black text-white font-['Outfit']">
                          Binge-Worthy TV Series
                        </h2>
                        <p className="text-xs text-slate-400">Original episodic dramas, sci-fi sagas, and animated masterpieces.</p>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('series')}
                      className="flex items-center gap-1 text-xs text-purple-400 hover:text-purple-300 font-bold transition"
                    >
                      <span>Explore Series ({series.length})</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                    {series.slice(0, 5).map((s) => (
                      <MediaCard
                        key={s.id}
                        type="series"
                        item={s}
                        onSelect={(type, item) => setDetailModalItem({ type, item })}
                        onOpenTrailer={handleOpenTrailer}
                        isSaved={savedIds.has(s.id)}
                        onToggleSave={toggleSave}
                        isAdmin={isAdmin}
                        onEditAdmin={handleEditAdminFromCard}
                      />
                    ))}
                  </div>
                </section>

                {/* 4. Articles & Editorial Chronicles */}
                <ArticlesSection
                  articles={articles}
                  onOpenArticleModal={setActiveArticleModal}
                  savedIds={savedIds}
                  onToggleSave={toggleSave}
                />

              </div>
            )}

            {/* ================= TAB: MOVIES ONLY ================= */}
            {activeTab === 'movies' && (
              <div className="space-y-6">
                <div className="border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-black text-white font-['Outfit'] flex items-center gap-3">
                    <Film className="w-7 h-7 text-amber-400" />
                    <span>EDIXIAL Cinema & Movie Catalog</span>
                  </h1>
                  <p className="text-sm text-slate-400 mt-1">
                    Explore high-definition movies with official trailers, synopsis, cast information, and ratings.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                  {filteredMovies.map((movie) => (
                    <MediaCard
                      key={movie.id}
                      type="movie"
                      item={movie}
                      onSelect={(type, item) => setDetailModalItem({ type, item })}
                      onOpenTrailer={handleOpenTrailer}
                      isSaved={savedIds.has(movie.id)}
                      onToggleSave={toggleSave}
                      isAdmin={isAdmin}
                      onEditAdmin={handleEditAdminFromCard}
                    />
                  ))}
                </div>

                {filteredMovies.length === 0 && (
                  <div className="p-12 text-center bg-[#0d111b] border border-white/5 rounded-3xl">
                    <Film className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-white">No Movies Found</h3>
                    <p className="text-xs text-slate-400 mt-1">Try resetting your search query or genre filter.</p>
                  </div>
                )}
              </div>
            )}

            {/* ================= TAB: GAMES ONLY ================= */}
            {activeTab === 'games' && (
              <div className="space-y-6">
                <div className="border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-black text-white font-['Outfit'] flex items-center gap-3">
                    <Gamepad2 className="w-7 h-7 text-cyan-400" />
                    <span>Next-Gen Video Games Database</span>
                  </h1>
                  <p className="text-sm text-slate-400 mt-1">
                    Browse next-generation PC and console games, view system requirements, trailers, and platforms.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                  {filteredGames.map((game) => (
                    <MediaCard
                      key={game.id}
                      type="game"
                      item={game}
                      onSelect={(type, item) => setDetailModalItem({ type, item })}
                      onOpenTrailer={handleOpenTrailer}
                      isSaved={savedIds.has(game.id)}
                      onToggleSave={toggleSave}
                      isAdmin={isAdmin}
                      onEditAdmin={handleEditAdminFromCard}
                    />
                  ))}
                </div>

                {filteredGames.length === 0 && (
                  <div className="p-12 text-center bg-[#0d111b] border border-white/5 rounded-3xl">
                    <Gamepad2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-white">No Games Found</h3>
                    <p className="text-xs text-slate-400 mt-1">Try adjusting your search criteria.</p>
                  </div>
                )}
              </div>
            )}

            {/* ================= TAB: SERIES ONLY ================= */}
            {activeTab === 'series' && (
              <div className="space-y-6">
                <div className="border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-black text-white font-['Outfit'] flex items-center gap-3">
                    <Tv className="w-7 h-7 text-purple-400" />
                    <span>Television & Streaming Series</span>
                  </h1>
                  <p className="text-sm text-slate-400 mt-1">
                    Keep track of seasonal releases, episode counts, creators, and streaming platforms.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
                  {filteredSeries.map((s) => (
                    <MediaCard
                      key={s.id}
                      type="series"
                      item={s}
                      onSelect={(type, item) => setDetailModalItem({ type, item })}
                      onOpenTrailer={handleOpenTrailer}
                      isSaved={savedIds.has(s.id)}
                      onToggleSave={toggleSave}
                      isAdmin={isAdmin}
                      onEditAdmin={handleEditAdminFromCard}
                    />
                  ))}
                </div>

                {filteredSeries.length === 0 && (
                  <div className="p-12 text-center bg-[#0d111b] border border-white/5 rounded-3xl">
                    <Tv className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-white">No Series Found</h3>
                    <p className="text-xs text-slate-400 mt-1">Try resetting your search parameters.</p>
                  </div>
                )}
              </div>
            )}

            {/* ================= TAB: ARTICLES & NEWS ================= */}
            {activeTab === 'articles' && (
              <ArticlesSection
                articles={articles}
                onOpenArticleModal={setActiveArticleModal}
                savedIds={savedIds}
                onToggleSave={toggleSave}
              />
            )}

            {/* ================= TAB: SAVED / WATCHLIST ================= */}
            {activeTab === 'saved' && (
              <div className="space-y-8">
                <div className="border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-black text-white font-['Outfit'] flex items-center gap-3">
                    <Bookmark className="w-7 h-7 text-amber-400" />
                    <span>My Saved Entertainment Watchlist</span>
                  </h1>
                  <p className="text-sm text-slate-400 mt-1">
                    Your personal collection of saved movies, games, series, and articles ({totalSaved} items).
                  </p>
                </div>

                {totalSaved === 0 ? (
                  <div className="p-16 text-center bg-[#0d111b] border border-white/5 rounded-3xl space-y-4">
                    <Bookmark className="w-14 h-14 text-slate-600 mx-auto" />
                    <h3 className="text-lg font-bold text-white">Your Watchlist is Empty</h3>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      Click the bookmark icon on any movie poster, game, or series to save it here for instant access.
                    </p>
                    <button
                      onClick={() => setActiveTab('home')}
                      className="px-6 py-2.5 bg-amber-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-amber-500/20 hover:bg-amber-400 transition"
                    >
                      Browse EDIXIAL Portal
                    </button>
                  </div>
                ) : (
                  <div className="space-y-10">
                    {savedMovies.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <Film className="w-4 h-4 text-amber-400" /> Saved Movies ({savedMovies.length})
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                          {savedMovies.map((movie) => (
                            <MediaCard
                              key={movie.id}
                              type="movie"
                              item={movie}
                              onSelect={(type, item) => setDetailModalItem({ type, item })}
                              onOpenTrailer={handleOpenTrailer}
                              isSaved={true}
                              onToggleSave={toggleSave}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {savedGames.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <Gamepad2 className="w-4 h-4 text-cyan-400" /> Saved Games ({savedGames.length})
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                          {savedGames.map((game) => (
                            <MediaCard
                              key={game.id}
                              type="game"
                              item={game}
                              onSelect={(type, item) => setDetailModalItem({ type, item })}
                              onOpenTrailer={handleOpenTrailer}
                              isSaved={true}
                              onToggleSave={toggleSave}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {savedSeriesList.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <Tv className="w-4 h-4 text-purple-400" /> Saved Series ({savedSeriesList.length})
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                          {savedSeriesList.map((s) => (
                            <MediaCard
                              key={s.id}
                              type="series"
                              item={s}
                              onSelect={(type, item) => setDetailModalItem({ type, item })}
                              onOpenTrailer={handleOpenTrailer}
                              isSaved={true}
                              onToggleSave={toggleSave}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

          </div>
        )}
      </main>

      {/* Global Modals */}
      {/* 1. Detail Modal */}
      {detailModalItem && (
        <DetailModal
          isOpen={!!detailModalItem}
          onClose={() => setDetailModalItem(null)}
          type={detailModalItem.type}
          item={detailModalItem.item}
          onOpenTrailer={handleOpenTrailer}
          isSaved={savedIds.has(detailModalItem.item.id)}
          onToggleSave={toggleSave}
        />
      )}

      {/* 2. Trailer Modal */}
      <TrailerModal
        isOpen={trailerModalData.isOpen}
        onClose={() => setTrailerModalData({ isOpen: false })}
        trailerUrl={trailerModalData.url}
        title={trailerModalData.title}
      />

      {/* 3. Article Reading Modal */}
      <ArticleModal
        isOpen={!!activeArticleModal}
        onClose={() => setActiveArticleModal(null)}
        article={activeArticleModal}
      />

      {/* 4. Firebase Diagnostics & Netlify Domain Modal */}
      <FirebaseDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
      />

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        isAdmin={isAdmin}
      />

    </div>
  );
}
