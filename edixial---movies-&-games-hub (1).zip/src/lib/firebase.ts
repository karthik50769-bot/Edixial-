import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  User,
  Auth
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  Firestore,
  serverTimestamp
} from 'firebase/firestore';
import { AdminUser, FirebaseDiagnostics } from '../types';

// Default target Firebase configuration explicitly set to user's project
export const DEFAULT_FIREBASE_CONFIG = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "edixial-7b281.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "edixial-7b281",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "edixial-7b281.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || ""
};

// Owner & permanent super administrator email
export const OWNER_EMAIL = "obscuramovie99@gmail.com";

// Check if user has saved custom keys in localStorage for live Netlify/preview testing
export function getActiveFirebaseConfig() {
  try {
    const saved = localStorage.getItem('edixial_custom_firebase_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_FIREBASE_CONFIG,
        ...parsed,
        projectId: parsed.projectId || "edixial-7b281",
        authDomain: parsed.authDomain || "edixial-7b281.firebaseapp.com"
      };
    }
  } catch (e) {
    console.error("Error loading custom firebase config from storage:", e);
  }
  return DEFAULT_FIREBASE_CONFIG;
}

export function saveCustomFirebaseConfig(config: Partial<typeof DEFAULT_FIREBASE_CONFIG>) {
  try {
    localStorage.setItem('edixial_custom_firebase_config', JSON.stringify(config));
    window.location.reload();
  } catch (e) {
    console.error("Error saving custom firebase config:", e);
  }
}

export function clearCustomFirebaseConfig() {
  try {
    localStorage.removeItem('edixial_custom_firebase_config');
    window.location.reload();
  } catch (e) {
    console.error("Error clearing custom firebase config:", e);
  }
}

// Initialize Firebase App
let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let initError: string | null = null;

try {
  const currentConfig = getActiveFirebaseConfig();
  if (getApps().length === 0) {
    app = initializeApp(currentConfig);
  } else {
    app = getApp();
  }
  auth = getAuth(app);
  db = getFirestore(app);
} catch (error: any) {
  console.warn("Firebase initialization note:", error?.message || error);
  initError = error?.message || String(error);
}

export { app, auth, db };

// Google Auth Provider setup
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

/**
 * Sign in with Google with popup, falling back to redirect if popup is blocked
 */
export async function signInWithGoogle(): Promise<{ user: User | null; error: string | null }> {
  if (!auth) {
    return {
      user: null,
      error: "Firebase Auth is not initialized. Please ensure your Firebase config (API key and Project ID: edixial-7b281) is configured."
    };
  }

  try {
    const result = await signInWithPopup(auth, googleProvider);
    if (result.user) {
      // If the user is the owner, automatically register or verify in Firestore admins
      await verifyAndRegisterAdmin(result.user);
    }
    return { user: result.user, error: null };
  } catch (err: any) {
    console.error("Google Sign-In Error:", err);
    let errorMessage = err.message || "Failed to sign in with Google.";
    
    if (err.code === 'auth/unauthorized-domain') {
      const currentHost = typeof window !== 'undefined' ? window.location.hostname : '';
      errorMessage = `Firebase Error (auth/unauthorized-domain): The domain "${currentHost}" is not authorized in Firebase project "${getActiveFirebaseConfig().projectId}". Please add "${currentHost}" to Firebase Console → Authentication → Settings → Authorized domains.`;
    } else if (err.code === 'auth/popup-closed-by-user') {
      errorMessage = "Sign-in popup was closed before completing.";
    } else if (err.code === 'auth/popup-blocked') {
      try {
        await signInWithRedirect(auth, googleProvider);
        return { user: null, error: "Redirecting to Google Sign-In..." };
      } catch (redirectErr: any) {
        errorMessage = redirectErr.message || "Popup was blocked and redirect failed.";
      }
    } else if (err.code === 'auth/invalid-api-key' || err.code === 'auth/api-key-not-valid') {
      errorMessage = "Firebase API Key is missing or invalid for project edixial-7b281. Please provide a valid Firebase Web API key in settings.";
    }

    return { user: null, error: errorMessage };
  }
}

/**
 * Sign out
 */
export async function logOut(): Promise<void> {
  if (!auth) return;
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Sign out error:", error);
  }
}

/**
 * Check if the current user is an authorized admin
 */
export async function checkIsAdmin(user: User | null): Promise<boolean> {
  if (!user || !user.email) return false;

  const normalizedEmail = user.email.toLowerCase().trim();

  // 1. Direct Owner Email Match
  if (normalizedEmail === OWNER_EMAIL.toLowerCase()) {
    return true;
  }

  // 2. Check Local Admin Override list if stored
  try {
    const localAdmins = JSON.parse(localStorage.getItem('edixial_authorized_admins') || '[]');
    if (Array.isArray(localAdmins) && localAdmins.some((e: string) => e.toLowerCase() === normalizedEmail)) {
      return true;
    }
  } catch (e) {
    // Ignore local storage parse errors
  }

  // 3. Check Firestore `admins` collection if db is available
  if (db) {
    try {
      // Check document with UID as ID
      const adminDocRef = doc(db, 'admins', user.uid);
      const adminDocSnap = await getDoc(adminDocRef);
      if (adminDocSnap.exists() && adminDocSnap.data()?.status !== 'revoked') {
        return true;
      }

      // Check document with Email as ID
      const emailDocRef = doc(db, 'admins', normalizedEmail);
      const emailDocSnap = await getDoc(emailDocRef);
      if (emailDocSnap.exists() && emailDocSnap.data()?.status !== 'revoked') {
        return true;
      }

      // Check users collection for role === 'admin' or 'owner'
      const userDocRef = doc(db, 'users', user.uid);
      const userDocSnap = await getDoc(userDocRef);
      if (userDocSnap.exists()) {
        const role = userDocSnap.data()?.role;
        if (role === 'admin' || role === 'owner' || role === 'super_admin') {
          return true;
        }
      }
    } catch (firestoreErr) {
      console.warn("Firestore admin lookup note:", firestoreErr);
      // Fallback: If network/rules blocked firestore read, still allow the designated owner
      if (normalizedEmail === OWNER_EMAIL.toLowerCase()) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Ensures the logged-in owner is saved to Firestore admins
 */
export async function verifyAndRegisterAdmin(user: User): Promise<void> {
  const normalizedEmail = (user.email || '').toLowerCase().trim();
  const isOwner = normalizedEmail === OWNER_EMAIL.toLowerCase();

  // Always keep owner in local authorized cache
  try {
    const localAdmins: string[] = JSON.parse(localStorage.getItem('edixial_authorized_admins') || '[]');
    if (!localAdmins.includes(OWNER_EMAIL.toLowerCase())) {
      localAdmins.push(OWNER_EMAIL.toLowerCase());
      localStorage.setItem('edixial_authorized_admins', JSON.stringify(localAdmins));
    }
  } catch (e) {}

  if (db && isOwner) {
    try {
      const adminRef = doc(db, 'admins', user.uid);
      await setDoc(
        adminRef,
        {
          uid: user.uid,
          email: normalizedEmail,
          displayName: user.displayName || 'Owner Admin',
          photoURL: user.photoURL || '',
          role: 'owner',
          status: 'active',
          lastLogin: serverTimestamp(),
          updatedAt: new Date().toISOString()
        },
        { merge: true }
      );
    } catch (err) {
      console.warn("Auto-registering owner in Firestore note:", err);
    }
  }
}

/**
 * Add a new admin email (Callable by authorized admins)
 */
export async function addAdminByEmail(
  email: string,
  role: 'super_admin' | 'editor' = 'super_admin',
  addedByEmail: string = OWNER_EMAIL
): Promise<{ success: boolean; message: string }> {
  const cleanEmail = email.toLowerCase().trim();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    return { success: false, message: 'Invalid email address.' };
  }

  // Save to local cache
  try {
    const localAdmins: string[] = JSON.parse(localStorage.getItem('edixial_authorized_admins') || '[]');
    if (!localAdmins.includes(cleanEmail)) {
      localAdmins.push(cleanEmail);
      localStorage.setItem('edixial_authorized_admins', JSON.stringify(localAdmins));
    }
  } catch (e) {}

  // Save to Firestore if available
  if (db) {
    try {
      const docRef = doc(db, 'admins', cleanEmail);
      await setDoc(
        docRef,
        {
          uid: '',
          email: cleanEmail,
          displayName: cleanEmail.split('@')[0],
          role,
          status: 'active',
          addedAt: new Date().toISOString(),
          addedBy: addedByEmail
        },
        { merge: true }
      );
      return { success: true, message: `Admin authorization granted to ${cleanEmail}.` };
    } catch (err: any) {
      console.error("Error adding admin to Firestore:", err);
      return {
        success: true,
        message: `Admin added locally. (Firestore note: ${err.message || 'Saved in local permissions'})`
      };
    }
  }

  return { success: true, message: `Admin authorization granted to ${cleanEmail}.` };
}

/**
 * Remove an admin email
 */
export async function removeAdmin(email: string): Promise<boolean> {
  const cleanEmail = email.toLowerCase().trim();
  if (cleanEmail === OWNER_EMAIL.toLowerCase()) {
    return false; // Owner cannot be deleted
  }

  try {
    const localAdmins: string[] = JSON.parse(localStorage.getItem('edixial_authorized_admins') || '[]');
    const filtered = localAdmins.filter(e => e.toLowerCase() !== cleanEmail);
    localStorage.setItem('edixial_authorized_admins', JSON.stringify(filtered));
  } catch (e) {}

  if (db) {
    try {
      await deleteDoc(doc(db, 'admins', cleanEmail));
    } catch (e) {
      console.warn("Firestore delete admin note:", e);
    }
  }

  return true;
}

/**
 * Get current system diagnostics
 */
export function getFirebaseDiagnostics(): FirebaseDiagnostics {
  const cfg = getActiveFirebaseConfig();
  const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
  const hasCustom = typeof localStorage !== 'undefined' && !!localStorage.getItem('edixial_custom_firebase_config');

  return {
    projectId: cfg.projectId || "edixial-7b281",
    authDomain: cfg.authDomain || "edixial-7b281.firebaseapp.com",
    apiKeyMasked: cfg.apiKey ? `${cfg.apiKey.slice(0, 6)}...${cfg.apiKey.slice(-4)}` : "Not provided in env",
    currentHost,
    isConfigured: !!(cfg.projectId && (cfg.apiKey || cfg.authDomain)),
    hasCustomConfig: hasCustom,
    lastError: initError,
    authReady: !!auth
  };
}
