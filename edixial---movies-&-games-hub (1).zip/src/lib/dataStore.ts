import { Movie, Game, Series, Article, AdminUser } from '../types';
import { INITIAL_MOVIES, INITIAL_GAMES, INITIAL_SERIES, INITIAL_ARTICLES, INITIAL_ADMINS } from '../data/mockData';
import { db } from './firebase';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch
} from 'firebase/firestore';

const STORAGE_KEY_MOVIES = 'edixial_movies_data_v2';
const STORAGE_KEY_GAMES = 'edixial_games_data_v2';
const STORAGE_KEY_SERIES = 'edixial_series_data_v2';
const STORAGE_KEY_ARTICLES = 'edixial_articles_data_v2';
const STORAGE_KEY_ADMINS = 'edixial_admins_data_v2';

// Helper to load or init local storage
function getStored<T>(key: string, defaultData: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn(`Error reading ${key} from storage:`, e);
  }
  try {
    localStorage.setItem(key, JSON.stringify(defaultData));
  } catch (e) {}
  return defaultData;
}

function saveStored<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.warn(`Error saving ${key} to storage:`, e);
  }
}

// In-memory data caches
let currentMovies: Movie[] = getStored<Movie>(STORAGE_KEY_MOVIES, INITIAL_MOVIES);
let currentGames: Game[] = getStored<Game>(STORAGE_KEY_GAMES, INITIAL_GAMES);
let currentSeries: Series[] = getStored<Series>(STORAGE_KEY_SERIES, INITIAL_SERIES);
let currentArticles: Article[] = getStored<Article>(STORAGE_KEY_ARTICLES, INITIAL_ARTICLES);
let currentAdmins: AdminUser[] = getStored<AdminUser>(STORAGE_KEY_ADMINS, INITIAL_ADMINS);

type Listener<T> = (data: T[]) => void;
const movieListeners = new Set<Listener<Movie>>();
const gameListeners = new Set<Listener<Game>>();
const seriesListeners = new Set<Listener<Series>>();
const articleListeners = new Set<Listener<Article>>();
const adminListeners = new Set<Listener<AdminUser>>();

export function subscribeMovies(cb: Listener<Movie>) {
  movieListeners.add(cb);
  cb(currentMovies);
  return () => movieListeners.delete(cb);
}

export function subscribeGames(cb: Listener<Game>) {
  gameListeners.add(cb);
  cb(currentGames);
  return () => gameListeners.delete(cb);
}

export function subscribeSeries(cb: Listener<Series>) {
  seriesListeners.add(cb);
  cb(currentSeries);
  return () => seriesListeners.delete(cb);
}

export function subscribeArticles(cb: Listener<Article>) {
  articleListeners.add(cb);
  cb(currentArticles);
  return () => articleListeners.delete(cb);
}

export function subscribeAdmins(cb: Listener<AdminUser>) {
  adminListeners.add(cb);
  cb(currentAdmins);
  return () => adminListeners.delete(cb);
}

function notifyMovies(data: Movie[]) {
  currentMovies = data;
  saveStored(STORAGE_KEY_MOVIES, data);
  movieListeners.forEach(cb => cb(data));
}

function notifyGames(data: Game[]) {
  currentGames = data;
  saveStored(STORAGE_KEY_GAMES, data);
  gameListeners.forEach(cb => cb(data));
}

function notifySeries(data: Series[]) {
  currentSeries = data;
  saveStored(STORAGE_KEY_SERIES, data);
  seriesListeners.forEach(cb => cb(data));
}

function notifyArticles(data: Article[]) {
  currentArticles = data;
  saveStored(STORAGE_KEY_ARTICLES, data);
  articleListeners.forEach(cb => cb(data));
}

function notifyAdmins(data: AdminUser[]) {
  currentAdmins = data;
  saveStored(STORAGE_KEY_ADMINS, data);
  adminListeners.forEach(cb => cb(data));
}

// Setup real-time Firestore listeners if db is available
export function initializeFirestoreSync() {
  if (!db) return;

  try {
    onSnapshot(collection(db, 'movies'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreMovies: Movie[] = [];
        snapshot.forEach(doc => {
          firestoreMovies.push({ id: doc.id, ...doc.data() } as Movie);
        });
        notifyMovies(firestoreMovies);
      }
    }, (err) => console.warn("Firestore movies subscription note:", err.message));

    onSnapshot(collection(db, 'games'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreGames: Game[] = [];
        snapshot.forEach(doc => {
          firestoreGames.push({ id: doc.id, ...doc.data() } as Game);
        });
        notifyGames(firestoreGames);
      }
    }, (err) => console.warn("Firestore games subscription note:", err.message));

    onSnapshot(collection(db, 'series'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreSeries: Series[] = [];
        snapshot.forEach(doc => {
          firestoreSeries.push({ id: doc.id, ...doc.data() } as Series);
        });
        notifySeries(firestoreSeries);
      }
    }, (err) => console.warn("Firestore series subscription note:", err.message));

    onSnapshot(collection(db, 'articles'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreArticles: Article[] = [];
        snapshot.forEach(doc => {
          firestoreArticles.push({ id: doc.id, ...doc.data() } as Article);
        });
        notifyArticles(firestoreArticles);
      }
    }, (err) => console.warn("Firestore articles subscription note:", err.message));

    onSnapshot(collection(db, 'admins'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreAdmins: AdminUser[] = [];
        snapshot.forEach(doc => {
          firestoreAdmins.push({ uid: doc.id, ...doc.data() } as AdminUser);
        });
        notifyAdmins(firestoreAdmins);
      }
    }, (err) => console.warn("Firestore admins subscription note:", err.message));
  } catch (e) {
    console.warn("Error initializing Firestore listeners:", e);
  }
}

// =================== MOVIE CRUD ===================
export async function addMovie(movie: Omit<Movie, 'id' | 'createdAt' | 'updatedAt'>): Promise<Movie> {
  const newId = 'm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();
  const fullMovie: Movie = {
    ...movie,
    id: newId,
    createdAt: now,
    updatedAt: now
  };

  const updated = [fullMovie, ...currentMovies];
  notifyMovies(updated);

  if (db) {
    try {
      await setDoc(doc(db, 'movies', newId), fullMovie);
    } catch (e) {
      console.warn("Firestore addMovie note:", e);
    }
  }

  return fullMovie;
}

export async function updateMovie(id: string, updates: Partial<Movie>): Promise<void> {
  const now = new Date().toISOString();
  const updated = currentMovies.map(m => m.id === id ? { ...m, ...updates, updatedAt: now } : m);
  notifyMovies(updated);

  if (db) {
    try {
      await updateDoc(doc(db, 'movies', id), { ...updates, updatedAt: now });
    } catch (e) {
      console.warn("Firestore updateMovie note:", e);
    }
  }
}

export async function deleteMovie(id: string): Promise<void> {
  const updated = currentMovies.filter(m => m.id !== id);
  notifyMovies(updated);

  if (db) {
    try {
      await deleteDoc(doc(db, 'movies', id));
    } catch (e) {
      console.warn("Firestore deleteMovie note:", e);
    }
  }
}

// =================== GAME CRUD ===================
export async function addGame(game: Omit<Game, 'id' | 'createdAt' | 'updatedAt'>): Promise<Game> {
  const newId = 'g_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();
  const fullGame: Game = {
    ...game,
    id: newId,
    createdAt: now,
    updatedAt: now
  };

  const updated = [fullGame, ...currentGames];
  notifyGames(updated);

  if (db) {
    try {
      await setDoc(doc(db, 'games', newId), fullGame);
    } catch (e) {
      console.warn("Firestore addGame note:", e);
    }
  }

  return fullGame;
}

export async function updateGame(id: string, updates: Partial<Game>): Promise<void> {
  const now = new Date().toISOString();
  const updated = currentGames.map(g => g.id === id ? { ...g, ...updates, updatedAt: now } : g);
  notifyGames(updated);

  if (db) {
    try {
      await updateDoc(doc(db, 'games', id), { ...updates, updatedAt: now });
    } catch (e) {
      console.warn("Firestore updateGame note:", e);
    }
  }
}

export async function deleteGame(id: string): Promise<void> {
  const updated = currentGames.filter(g => g.id !== id);
  notifyGames(updated);

  if (db) {
    try {
      await deleteDoc(doc(db, 'games', id));
    } catch (e) {
      console.warn("Firestore deleteGame note:", e);
    }
  }
}

// =================== SERIES CRUD ===================
export async function addSeries(series: Omit<Series, 'id' | 'createdAt' | 'updatedAt'>): Promise<Series> {
  const newId = 's_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();
  const fullSeries: Series = {
    ...series,
    id: newId,
    createdAt: now,
    updatedAt: now
  };

  const updated = [fullSeries, ...currentSeries];
  notifySeries(updated);

  if (db) {
    try {
      await setDoc(doc(db, 'series', newId), fullSeries);
    } catch (e) {
      console.warn("Firestore addSeries note:", e);
    }
  }

  return fullSeries;
}

export async function updateSeries(id: string, updates: Partial<Series>): Promise<void> {
  const now = new Date().toISOString();
  const updated = currentSeries.map(s => s.id === id ? { ...s, ...updates, updatedAt: now } : s);
  notifySeries(updated);

  if (db) {
    try {
      await updateDoc(doc(db, 'series', id), { ...updates, updatedAt: now });
    } catch (e) {
      console.warn("Firestore updateSeries note:", e);
    }
  }
}

export async function deleteSeries(id: string): Promise<void> {
  const updated = currentSeries.filter(s => s.id !== id);
  notifySeries(updated);

  if (db) {
    try {
      await deleteDoc(doc(db, 'series', id));
    } catch (e) {
      console.warn("Firestore deleteSeries note:", e);
    }
  }
}

// =================== ARTICLE CRUD ===================
export async function addArticle(article: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>): Promise<Article> {
  const newId = 'a_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();
  const fullArticle: Article = {
    ...article,
    id: newId,
    createdAt: now,
    updatedAt: now
  };

  const updated = [fullArticle, ...currentArticles];
  notifyArticles(updated);

  if (db) {
    try {
      await setDoc(doc(db, 'articles', newId), fullArticle);
    } catch (e) {
      console.warn("Firestore addArticle note:", e);
    }
  }

  return fullArticle;
}

export async function updateArticle(id: string, updates: Partial<Article>): Promise<void> {
  const now = new Date().toISOString();
  const updated = currentArticles.map(a => a.id === id ? { ...a, ...updates, updatedAt: now } : a);
  notifyArticles(updated);

  if (db) {
    try {
      await updateDoc(doc(db, 'articles', id), { ...updates, updatedAt: now });
    } catch (e) {
      console.warn("Firestore updateArticle note:", e);
    }
  }
}

export async function deleteArticle(id: string): Promise<void> {
  const updated = currentArticles.filter(a => a.id !== id);
  notifyArticles(updated);

  if (db) {
    try {
      await deleteDoc(doc(db, 'articles', id));
    } catch (e) {
      console.warn("Firestore deleteArticle note:", e);
    }
  }
}

// =================== SEED / CLOUD SYNC ===================
export async function pushAllToFirestore(): Promise<{ count: number; error?: string }> {
  if (!db) {
    return { count: 0, error: "Firestore instance not available." };
  }

  try {
    let count = 0;
    const batch = writeBatch(db);

    // Push movies
    for (const movie of currentMovies) {
      batch.set(doc(db, 'movies', movie.id), movie, { merge: true });
      count++;
    }

    // Push games
    for (const game of currentGames) {
      batch.set(doc(db, 'games', game.id), game, { merge: true });
      count++;
    }

    // Push series
    for (const series of currentSeries) {
      batch.set(doc(db, 'series', series.id), series, { merge: true });
      count++;
    }

    // Push articles
    for (const article of currentArticles) {
      batch.set(doc(db, 'articles', article.id), article, { merge: true });
      count++;
    }

    // Push admins
    for (const admin of currentAdmins) {
      const docId = admin.uid || admin.email;
      batch.set(doc(db, 'admins', docId), admin, { merge: true });
      count++;
    }

    await batch.commit();
    return { count };
  } catch (err: any) {
    console.error("Firestore push error:", err);
    return { count: 0, error: err.message || "Failed to commit batch to Firestore." };
  }
}

// Reset local data back to initial seeds
export function resetToDefaults(): void {
  notifyMovies(INITIAL_MOVIES);
  notifyGames(INITIAL_GAMES);
  notifySeries(INITIAL_SERIES);
  notifyArticles(INITIAL_ARTICLES);
  notifyAdmins(INITIAL_ADMINS);
}
