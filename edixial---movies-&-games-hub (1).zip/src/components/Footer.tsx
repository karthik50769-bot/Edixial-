import React from 'react';
import { Film, Gamepad2, Tv, Shield, Heart, ExternalLink, Sliders } from 'lucide-react';
import { ActiveTab } from '../types';
import { OWNER_EMAIL } from '../lib/firebase';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenDiagnostics: () => void;
  isAdmin: boolean;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, onOpenDiagnostics, isAdmin }) => {
  return (
    <footer className="w-full bg-[#06080c] border-t border-white/5 text-slate-400 text-xs py-12 px-4 sm:px-6 lg:px-8 mt-20">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
        
        {/* Brand Col */}
        <div className="space-y-4 md:col-span-1">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 text-black font-black text-sm">
              EX
            </div>
            <span className="font-extrabold text-xl tracking-wider text-white font-['Outfit']">
              EDIXIAL
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            The premier cinematic and next-generation gaming portal. Streaming blockbuster trailers, game specs, and critique journalism.
          </p>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-slate-900 border border-slate-800 text-[10px] text-amber-400 font-mono rounded">
              Firebase: edixial-7b281
            </span>
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-sm font-['Outfit']">Entertainment Hub</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => setActiveTab('movies')} className="hover:text-amber-400 transition">
                Cinema & Blockbusters
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('games')} className="hover:text-amber-400 transition">
                Next-Gen Video Games
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('series')} className="hover:text-amber-400 transition">
                Original TV Series
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('articles')} className="hover:text-amber-400 transition">
                Reviews & Editorial Chronicles
              </button>
            </li>
          </ul>
        </div>

        {/* Administration & Security */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-sm font-['Outfit']">Control & Security</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button
                onClick={() => setActiveTab('admin')}
                className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>EDIXIAL Admin Console (/admin)</span>
              </button>
            </li>
            <li>
              <button onClick={onOpenDiagnostics} className="hover:text-slate-200 flex items-center gap-1">
                <Sliders className="w-3.5 h-3.5 text-slate-500" />
                <span>Diagnostics & Netlify Domains</span>
              </button>
            </li>
            <li className="text-[11px] text-slate-500">
              Authorized Owner: <span className="font-mono text-slate-400">{OWNER_EMAIL}</span>
            </li>
          </ul>
        </div>

        {/* Cloud Status */}
        <div className="space-y-3">
          <h4 className="text-white font-bold text-sm font-['Outfit']">Infrastructure</h4>
          <p className="text-xs text-slate-400">
            Engineered with Google Firebase Authentication, Firestore Rules, and React.
          </p>
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
            <div className="text-[11px] flex justify-between">
              <span>Google Sign-In:</span>
              <span className="text-emerald-400 font-medium">Active</span>
            </div>
            <div className="text-[11px] flex justify-between">
              <span>Security Rules:</span>
              <span className="text-amber-400 font-medium">Protected</span>
            </div>
          </div>
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <p>© {new Date().getFullYear()} EDIXIAL Entertainment Portal. All rights reserved.</p>
        <p className="flex items-center gap-1">
          Designed for Cinema & Gaming Enthusiasts
        </p>
      </div>
    </footer>
  );
};
