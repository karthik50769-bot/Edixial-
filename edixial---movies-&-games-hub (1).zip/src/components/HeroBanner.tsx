import React, { useState, useEffect } from 'react';
import { Play, Info, Plus, Check, Star, Sparkles, ChevronLeft, ChevronRight, Film, Gamepad2, Tv } from 'lucide-react';
import { Movie, Game, Series } from '../types';

interface HeroBannerProps {
  featuredItems: Array<{
    type: 'movie' | 'game' | 'series';
    data: Movie | Game | Series;
  }>;
  onSelect: (type: 'movie' | 'game' | 'series', item: Movie | Game | Series) => void;
  onOpenTrailer: (url?: string, title?: string) => void;
  savedIds: Set<string>;
  onToggleSave: (id: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredItems,
  onSelect,
  onOpenTrailer,
  savedIds,
  onToggleSave
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (featuredItems.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredItems.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [featuredItems.length]);

  if (!featuredItems.length) return null;

  const current = featuredItems[currentIndex];
  const isSaved = savedIds.has(current.data.id);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? featuredItems.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredItems.length);
  };

  const getTypeBadge = (type: 'movie' | 'game' | 'series') => {
    switch (type) {
      case 'movie':
        return { label: 'BLOCKBUSTER MOVIE', icon: Film, color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'game':
        return { label: 'FEATURED GAME', icon: Gamepad2, color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' };
      case 'series':
        return { label: 'ORIGINAL SERIES', icon: Tv, color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
    }
  };

  const badge = getTypeBadge(current.type);
  const BadgeIcon = badge.icon;
  const rating = current.data.rating;

  return (
    <div className="relative w-full h-[520px] sm:h-[620px] overflow-hidden rounded-3xl border border-white/10 bg-slate-950 shadow-2xl mb-12">
      {/* Background Image with Gradient Mask */}
      <div className="absolute inset-0">
        <img
          src={current.data.backdropUrl || current.data.posterUrl}
          alt={current.data.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transition-all duration-1000 ease-out brightness-75"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080a0f] via-[#080a0f]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#080a0f] via-[#080a0f]/80 to-transparent" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 h-full max-w-7xl mx-auto px-6 sm:px-10 flex flex-col justify-end pb-12 sm:pb-16 max-w-3xl">
        
        {/* Type & Rating Tag */}
        <div className="flex flex-wrap items-center gap-2.5 mb-3">
          <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase border ${badge.color}`}>
            <BadgeIcon className="w-3.5 h-3.5" />
            <span>{badge.label}</span>
          </div>

          <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full text-xs font-bold">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{rating.toFixed(1)}</span>
          </div>

          {'releaseYear' in current.data && (
            <span className="text-xs text-slate-300 font-medium px-2 py-0.5 bg-slate-900/80 border border-slate-800 rounded-md">
              {current.data.releaseYear}
            </span>
          )}

          {'releaseDate' in current.data && (
            <span className="text-xs text-slate-300 font-medium px-2 py-0.5 bg-slate-900/80 border border-slate-800 rounded-md">
              {current.data.releaseDate}
            </span>
          )}

          {'genres' in current.data && (
            <span className="text-xs text-slate-400 hidden sm:inline">
              • {current.data.genres.slice(0, 3).join(', ')}
            </span>
          )}
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-none mb-4 font-['Outfit'] drop-shadow-lg">
          {current.data.title}
        </h1>

        {/* Synopsis */}
        <p className="text-sm sm:text-base text-slate-300 line-clamp-3 mb-6 font-normal leading-relaxed max-w-2xl drop-shadow">
          {current.data.synopsis}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onOpenTrailer(current.data.trailerUrl, current.data.title)}
            className="flex items-center gap-2.5 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-sm rounded-xl shadow-xl shadow-amber-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            <Play className="w-4 h-4 fill-black" />
            <span>Watch Trailer</span>
          </button>

          <button
            onClick={() => onSelect(current.type, current.data)}
            className="flex items-center gap-2 px-5 py-3 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white font-semibold text-sm rounded-xl backdrop-blur-md transition-all"
          >
            <Info className="w-4 h-4 text-amber-400" />
            <span>Details & Cast</span>
          </button>

          <button
            onClick={() => onToggleSave(current.data.id)}
            className={`p-3 rounded-xl border transition-all ${
              isSaved
                ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
            title={isSaved ? 'Saved to Watchlist' : 'Add to Watchlist'}
          >
            {isSaved ? <Check className="w-4 h-4 font-bold" /> : <Plus className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Navigation Arrows */}
      <div className="absolute bottom-6 right-6 z-20 flex items-center gap-2">
        <button
          onClick={prevSlide}
          className="p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition backdrop-blur"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-mono text-slate-400 px-1">
          {currentIndex + 1} / {featuredItems.length}
        </span>
        <button
          onClick={nextSlide}
          className="p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition backdrop-blur"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
