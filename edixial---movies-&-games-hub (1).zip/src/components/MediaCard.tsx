import React from 'react';
import { Star, Play, Bookmark, Check, Edit3, Film, Gamepad2, Tv } from 'lucide-react';
import { Movie, Game, Series } from '../types';

interface MediaCardProps {
  type: 'movie' | 'game' | 'series';
  item: Movie | Game | Series;
  onSelect: (type: 'movie' | 'game' | 'series', item: Movie | Game | Series) => void;
  onOpenTrailer: (url?: string, title?: string) => void;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  isAdmin?: boolean;
  onEditAdmin?: (type: 'movie' | 'game' | 'series', item: Movie | Game | Series) => void;
}

export const MediaCard: React.FC<MediaCardProps> = ({
  type,
  item,
  onSelect,
  onOpenTrailer,
  isSaved,
  onToggleSave,
  isAdmin,
  onEditAdmin
}) => {
  const isMovie = type === 'movie';
  const isGame = type === 'game';
  const isSeries = type === 'series';

  const movie = isMovie ? (item as Movie) : null;
  const game = isGame ? (item as Game) : null;
  const series = isSeries ? (item as Series) : null;

  return (
    <div className="group relative flex flex-col bg-[#0f141f] border border-white/5 hover:border-amber-500/40 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 transform hover:-translate-y-1.5">
      
      {/* Poster Image Container */}
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-900">
        <img
          src={item.posterUrl}
          alt={item.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // Fallback placeholder if broken URL
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80';
          }}
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f141f] via-transparent to-black/40 opacity-80 group-hover:opacity-60 transition-opacity" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-black/70 backdrop-blur-md rounded-lg border border-white/10 text-[11px] font-bold text-amber-400">
            <Star className="w-3 h-3 fill-amber-400" />
            <span>{item.rating.toFixed(1)}</span>
          </div>

          <div className="flex items-center gap-1.5">
            {isAdmin && onEditAdmin && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEditAdmin(type, item);
                }}
                title="Edit in Admin Panel"
                className="p-1.5 bg-amber-500 text-black hover:bg-amber-400 rounded-lg shadow-md transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave(item.id);
              }}
              title={isSaved ? "Remove from watchlist" : "Save to watchlist"}
              className={`p-1.5 rounded-lg backdrop-blur-md border transition ${
                isSaved
                  ? 'bg-amber-500 text-black border-amber-400'
                  : 'bg-black/60 text-slate-300 border-white/10 hover:text-white hover:bg-black/80'
              }`}
            >
              {isSaved ? <Check className="w-3.5 h-3.5 font-bold" /> : <Bookmark className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Hover Trailer Play Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 bg-black/40 backdrop-blur-[2px]">
          <button
            onClick={() => onOpenTrailer(item.trailerUrl, item.title)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs rounded-xl shadow-xl shadow-amber-500/30 transform scale-90 group-hover:scale-100 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-black" />
            <span>Trailer</span>
          </button>
        </div>

        {/* Bottom Type & Year / Platform strip */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] text-slate-300 z-10 font-medium">
          <span className="flex items-center gap-1 text-amber-400/90 font-semibold">
            {isMovie && <Film className="w-3 h-3" />}
            {isGame && <Gamepad2 className="w-3 h-3" />}
            {isSeries && <Tv className="w-3 h-3" />}
            <span>{isMovie ? 'Movie' : isGame ? 'Game' : 'Series'}</span>
          </span>

          <span className="px-1.5 py-0.5 bg-black/60 rounded border border-white/5 font-mono text-[10px]">
            {movie && movie.releaseYear}
            {game && game.releaseDate}
            {series && `S${series.totalSeasons} • ${series.releaseYear}`}
          </span>
        </div>
      </div>

      {/* Card Info Content */}
      <div
        onClick={() => onSelect(type, item)}
        className="p-4 flex flex-col flex-grow justify-between cursor-pointer"
      >
        <div>
          <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-amber-400 transition-colors line-clamp-1 font-['Outfit']">
            {item.title}
          </h3>

          <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
            {item.synopsis}
          </p>
        </div>

        {/* Tags / Extra info */}
        <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
          <div className="truncate text-slate-400 text-[11px]">
            {item.genres ? item.genres.slice(0, 2).join(' • ') : ''}
          </div>

          <span className="text-amber-400/80 font-semibold hover:text-amber-300 text-xs ml-2 whitespace-nowrap">
            Explore →
          </span>
        </div>
      </div>
    </div>
  );
};
