import React from 'react';
import {
  X,
  Star,
  Play,
  Bookmark,
  Check,
  Calendar,
  Clock,
  Globe,
  Film,
  Gamepad2,
  Tv,
  Layers,
  Monitor,
  Cpu,
  HardDrive,
  Users,
  Award,
  Sparkles
} from 'lucide-react';
import { Movie, Game, Series } from '../types';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'movie' | 'game' | 'series' | null;
  item: Movie | Game | Series | null;
  onOpenTrailer: (url?: string, title?: string) => void;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({
  isOpen,
  onClose,
  type,
  item,
  onOpenTrailer,
  isSaved,
  onToggleSave
}) => {
  if (!isOpen || !item || !type) return null;

  const isMovie = type === 'movie';
  const isGame = type === 'game';
  const isSeries = type === 'series';

  const movie = isMovie ? (item as Movie) : null;
  const game = isGame ? (item as Game) : null;
  const series = isSeries ? (item as Series) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#0c101a] border border-amber-500/20 rounded-3xl shadow-2xl text-slate-200 my-auto">
        
        {/* Backdrop Header with Poster */}
        <div className="relative h-72 sm:h-96 w-full overflow-hidden bg-slate-950">
          <img
            src={item.backdropUrl || item.posterUrl}
            alt={item.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c101a] via-[#0c101a]/60 to-black/30" />
          
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-slate-300 hover:text-white border border-white/10 backdrop-blur transition"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Quick Details Floating in Header */}
          <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {isMovie ? 'Cinema Feature' : isGame ? 'Next-Gen Game' : 'Television Series'}
                </span>
                <div className="flex items-center gap-1 px-2.5 py-1 bg-black/70 rounded-full border border-white/10 text-xs font-bold text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{item.rating.toFixed(1)} / 10</span>
                </div>
              </div>

              <h2 className="text-2xl sm:text-4xl font-black text-white font-['Outfit'] drop-shadow-md">
                {item.title}
              </h2>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => onOpenTrailer(item.trailerUrl, item.title)}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-amber-500/30 transition"
              >
                <Play className="w-4 h-4 fill-black" />
                <span>Trailer</span>
              </button>

              <button
                onClick={() => onToggleSave(item.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-semibold transition ${
                  isSaved
                    ? 'bg-amber-500 text-black border-amber-400'
                    : 'bg-slate-900/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                {isSaved ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                <span>{isSaved ? 'In Watchlist' : 'Watchlist'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Main Info Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: Synopsis, Genres, Details */}
            <div className="md:col-span-2 space-y-5">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Synopsis</h4>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {item.synopsis}
                </p>
              </div>

              {/* Genres */}
              {item.genres && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Genres & Themes</h4>
                  <div className="flex flex-wrap gap-2">
                    {item.genres.map((g, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 font-medium"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Cast or Team */}
              {(movie?.cast || series?.cast) && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Principal Cast</h4>
                  <div className="flex flex-wrap gap-2">
                    {(movie?.cast || series?.cast || []).map((actor, idx) => (
                      <span
                        key={idx}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-xl text-xs text-slate-200"
                      >
                        <Users className="w-3.5 h-3.5 text-amber-400" />
                        <span>{actor}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Game System Specs if available */}
              {game?.systemRequirements && (
                <div className="p-4 bg-slate-950/70 border border-slate-800/80 rounded-2xl space-y-2">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Monitor className="w-4 h-4" /> Recommended PC Hardware
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                    {game.systemRequirements.os && <div><span className="text-slate-500">OS:</span> {game.systemRequirements.os}</div>}
                    {game.systemRequirements.processor && <div><span className="text-slate-500">CPU:</span> {game.systemRequirements.processor}</div>}
                    {game.systemRequirements.graphics && <div><span className="text-slate-500">GPU:</span> {game.systemRequirements.graphics}</div>}
                    {game.systemRequirements.memory && <div><span className="text-slate-500">RAM:</span> {game.systemRequirements.memory}</div>}
                    {game.systemRequirements.storage && <div><span className="text-slate-500">Storage:</span> {game.systemRequirements.storage}</div>}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column: Metadata Cards */}
            <div className="space-y-4">
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm pb-2 border-b border-slate-800 font-['Outfit']">
                  Specifications
                </h4>

                {movie && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Release Year</span>
                      <span className="text-slate-200 font-semibold">{movie.releaseYear}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Duration</span>
                      <span className="text-slate-200 font-semibold">{movie.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Director</span>
                      <span className="text-amber-400 font-semibold">{movie.director}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status</span>
                      <span className="text-emerald-400 font-semibold">{movie.status}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Language</span>
                      <span className="text-slate-200">{movie.language}</span>
                    </div>
                  </>
                )}

                {game && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Developer</span>
                      <span className="text-amber-400 font-semibold">{game.developer}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Publisher</span>
                      <span className="text-slate-200">{game.publisher}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Release Date</span>
                      <span className="text-slate-200 font-semibold">{game.releaseDate}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-1">Platforms</span>
                      <div className="flex flex-wrap gap-1">
                        {game.platforms.map((p, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-slate-800 text-cyan-300 rounded text-[10px] font-mono">
                            {p}
                          </span>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                {series && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Seasons</span>
                      <span className="text-slate-200 font-semibold">{series.totalSeasons} Season{series.totalSeasons > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Episodes</span>
                      <span className="text-slate-200 font-semibold">{series.totalEpisodes} Episodes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Creator</span>
                      <span className="text-amber-400 font-semibold">{series.creator}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Network</span>
                      <span className="text-purple-300 font-semibold">{series.network || 'Streaming'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status</span>
                      <span className="text-emerald-400 font-semibold">{series.status}</span>
                    </div>
                  </>
                )}
              </div>

              {/* Poster Thumbnail */}
              <div className="rounded-2xl overflow-hidden border border-slate-800 shadow-md">
                <img
                  src={item.posterUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-48 object-cover"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400">EDIXIAL Cinematic Entertainment Database</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition font-medium"
          >
            Close Details
          </button>
        </div>

      </div>
    </div>
  );
};
