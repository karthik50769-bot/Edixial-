import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  ExternalLink,
  Settings,
  RefreshCw,
  Trash2,
  X,
  Key,
  Globe,
  Database
} from 'lucide-react';
import {
  getFirebaseDiagnostics,
  getActiveFirebaseConfig,
  saveCustomFirebaseConfig,
  clearCustomFirebaseConfig,
  OWNER_EMAIL
} from '../lib/firebase';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseDiagnosticsModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const diagnostics = getFirebaseDiagnostics();
  const currentConfig = getActiveFirebaseConfig();
  const [copied, setCopied] = useState<string | null>(null);

  // Edit config state
  const [apiKeyInput, setApiKeyInput] = useState(currentConfig.apiKey || '');
  const [projectIdInput, setProjectIdInput] = useState(currentConfig.projectId || 'edixial-7b281');
  const [authDomainInput, setAuthDomainInput] = useState(currentConfig.authDomain || 'edixial-7b281.firebaseapp.com');
  const [storageBucketInput, setStorageBucketInput] = useState(currentConfig.storageBucket || 'edixial-7b281.appspot.com');
  const [appIdInput, setAppIdInput] = useState(currentConfig.appId || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveCustomFirebaseConfig({
      apiKey: apiKeyInput.trim(),
      projectId: projectIdInput.trim() || 'edixial-7b281',
      authDomain: authDomainInput.trim() || 'edixial-7b281.firebaseapp.com',
      storageBucket: storageBucketInput.trim() || 'edixial-7b281.appspot.com',
      appId: appIdInput.trim()
    });
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1000);
  };

  const currentHostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
  const netlifyDomain = 'unique-rabanadas-044bed.netlify.app';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0d111b] border border-amber-500/30 rounded-2xl shadow-2xl p-6 text-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white tracking-wide">Firebase & Netlify Diagnostics</h3>
              <p className="text-xs text-slate-400">Project ID: <span className="font-mono text-amber-400 font-semibold">{diagnostics.projectId}</span></p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Status Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-5">
          <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
            <div className="text-xs text-slate-400 font-medium">Project ID</div>
            <div className="text-sm font-semibold text-amber-400 font-mono mt-0.5 truncate">
              {diagnostics.projectId}
            </div>
            <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
              <CheckCircle2 className="w-3 h-3" /> Exact user target
            </div>
          </div>

          <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
            <div className="text-xs text-slate-400 font-medium">Current Hostname</div>
            <div className="text-sm font-semibold text-cyan-300 font-mono mt-0.5 truncate">
              {currentHostname}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              {currentHostname === netlifyDomain ? '🎯 Netlify Live Site' : 'Preview / Local Host'}
            </div>
          </div>

          <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
            <div className="text-xs text-slate-400 font-medium">Super Admin</div>
            <div className="text-sm font-semibold text-purple-300 font-mono mt-0.5 truncate">
              {OWNER_EMAIL}
            </div>
            <div className="text-[10px] text-purple-400 mt-1">
              Authorized Owner
            </div>
          </div>
        </div>

        {/* How to Fix auth/unauthorized-domain */}
        <div className="mb-6 p-4 bg-amber-950/20 border border-amber-500/40 rounded-xl">
          <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm mb-2">
            <AlertTriangle className="w-4 h-4" />
            Fixing "Firebase Error: auth/unauthorized-domain"
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            Firebase Authentication checks the origin domain for every Google Sign-In request. Ensure both domains below are added to your Firebase Console:
          </p>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 bg-slate-950/70 border border-slate-800 rounded-lg text-xs font-mono">
              <div>
                <span className="text-slate-400 mr-2">1. Netlify Domain:</span>
                <span className="text-emerald-400 font-bold">{netlifyDomain}</span>
              </div>
              <button
                onClick={() => copyToClipboard(netlifyDomain, 'netlify')}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] transition"
              >
                {copied === 'netlify' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied === 'netlify' ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="flex items-center justify-between p-2 bg-slate-950/70 border border-slate-800 rounded-lg text-xs font-mono">
              <div>
                <span className="text-slate-400 mr-2">2. Current Window Host:</span>
                <span className="text-cyan-300 font-bold">{currentHostname}</span>
              </div>
              <button
                onClick={() => copyToClipboard(currentHostname, 'host')}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] transition"
              >
                {copied === 'host' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied === 'host' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between">
            <a
              href={`https://console.firebase.google.com/project/edixial-7b281/authentication/settings`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 font-medium underline underline-offset-2"
            >
              Open Firebase Console → Authentication → Settings <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Configuration Edit Form */}
        <form onSubmit={handleSave} className="space-y-4 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-amber-400" />
              Firebase Web Configuration Values
            </h4>
            {diagnostics.hasCustomConfig && (
              <button
                type="button"
                onClick={clearCustomFirebaseConfig}
                className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 transition"
              >
                <Trash2 className="w-3.5 h-3.5" /> Reset to defaults
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Project ID</label>
              <input
                type="text"
                value={projectIdInput}
                onChange={(e) => setProjectIdInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:border-amber-500 focus:outline-none font-mono"
                placeholder="edixial-7b281"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Auth Domain</label>
              <input
                type="text"
                value={authDomainInput}
                onChange={(e) => setAuthDomainInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:border-amber-500 focus:outline-none font-mono"
                placeholder="edixial-7b281.firebaseapp.com"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-400 mb-1 flex items-center justify-between">
                <span>Firebase Web API Key (apiKey)</span>
                <span className="text-[11px] text-amber-400/80">Found in Firebase Project Settings → General</span>
              </label>
              <input
                type="text"
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:border-amber-500 focus:outline-none font-mono"
                placeholder="AIzaSy..."
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Storage Bucket</label>
              <input
                type="text"
                value={storageBucketInput}
                onChange={(e) => setStorageBucketInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:border-amber-500 focus:outline-none font-mono"
                placeholder="edixial-7b281.appspot.com"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">App ID (Optional)</label>
              <input
                type="text"
                value={appIdInput}
                onChange={(e) => setAppIdInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:border-amber-500 focus:outline-none font-mono"
                placeholder="1:656821100394:web:..."
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition"
            >
              Close
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-black bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-lg shadow-lg shadow-amber-500/20 transition flex items-center gap-1.5"
            >
              {saveSuccess ? (
                <>
                  <Check className="w-4 h-4" /> Applied!
                </>
              ) : (
                <>
                  <RefreshCw className="w-3.5 h-3.5" /> Save & Reload Firebase
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
