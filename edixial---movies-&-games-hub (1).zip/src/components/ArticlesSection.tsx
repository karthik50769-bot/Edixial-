import React, { useState } from 'react';
import { Newspaper, Calendar, Clock, User, Tag, Sparkles, ArrowRight, X, Share2, Bookmark, Check } from 'lucide-react';
import { Article } from '../types';

interface ArticlesSectionProps {
  articles: Article[];
  onOpenArticleModal: (article: Article) => void;
  savedIds: Set<string>;
  onToggleSave: (id: string) => void;
}

export const ArticlesSection: React.FC<ArticlesSectionProps> = ({
  articles,
  onOpenArticleModal,
  savedIds,
  onToggleSave
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Exclusive', 'News', 'Review', 'Feature', 'Guide'];

  const filtered = selectedCategory === 'All'
    ? articles
    : articles.filter(a => a.category.toLowerCase() === selectedCategory.toLowerCase());

  return (
    <div className="space-y-8">
      {/* Category Pills */}
      <div className="flex items-center justify-between flex-wrap gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white font-['Outfit'] flex items-center gap-2">
            <Newspaper className="w-6 h-6 text-amber-400" />
            <span>EDIXIAL Chronicles & Articles</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Cinematic critiques, game patch reports, and exclusive entertainment deep dives.
          </p>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto py-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                  : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((article) => {
          const isSaved = savedIds.has(article.id);
          return (
            <article
              key={article.id}
              onClick={() => onOpenArticleModal(article)}
              className="group flex flex-col bg-[#0f141f] border border-white/5 hover:border-amber-500/40 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
            >
              {/* Cover Image */}
              <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                <img
                  src={article.coverUrl}
                  alt={article.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f141f] via-transparent to-transparent" />

                {/* Top Category Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-amber-500 text-black text-[10px] font-black uppercase tracking-wider rounded-lg shadow">
                    {article.category}
                  </span>
                  {article.featured && (
                    <span className="px-2 py-1 bg-purple-500/90 text-white text-[10px] font-bold rounded-lg backdrop-blur">
                      Featured
                    </span>
                  )}
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSave(article.id);
                  }}
                  className={`absolute top-3 right-3 p-2 rounded-xl backdrop-blur border transition ${
                    isSaved
                      ? 'bg-amber-500 text-black border-amber-400'
                      : 'bg-black/60 text-slate-300 border-white/10 hover:text-white'
                  }`}
                >
                  {isSaved ? <Check className="w-3.5 h-3.5" /> : <Bookmark className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Body */}
              <div className="p-5 flex flex-col flex-grow justify-between space-y-4">
                <div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mb-2 font-medium">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      {new Date(article.publishedAt).toLocaleDateString()}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {article.readTime}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2 font-['Outfit']">
                    {article.title}
                  </h3>

                  <p className="text-xs text-slate-400 line-clamp-2 mt-2 leading-relaxed">
                    {article.excerpt}
                  </p>
                </div>

                {/* Author & Read CTA */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {article.author.avatar ? (
                      <img
                        src={article.author.avatar}
                        alt={article.author.name}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover ring-1 ring-white/10"
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-slate-800 text-amber-400 flex items-center justify-center text-[10px] font-bold">
                        {article.author.name[0]}
                      </div>
                    )}
                    <span className="text-xs text-slate-300 font-medium truncate max-w-[120px]">
                      {article.author.name}
                    </span>
                  </div>

                  <span className="flex items-center gap-1 text-xs font-semibold text-amber-400 group-hover:translate-x-1 transition-transform">
                    Read <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};

export const ArticleModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  article: Article | null;
}> = ({ isOpen, onClose, article }) => {
  if (!isOpen || !article) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#0d111b] border border-amber-500/30 rounded-3xl shadow-2xl text-slate-200 my-auto">
        
        {/* Cover */}
        <div className="relative h-64 sm:h-80 w-full overflow-hidden">
          <img
            src={article.coverUrl}
            alt={article.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d111b] via-[#0d111b]/40 to-transparent" />

          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/70 hover:bg-black text-slate-300 hover:text-white border border-white/10 backdrop-blur transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-10 space-y-6">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-amber-500 text-black text-xs font-extrabold rounded-lg uppercase tracking-wider">
              {article.category}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {article.readTime}
            </span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white font-['Outfit'] leading-tight">
            {article.title}
          </h1>

          <div className="flex items-center gap-3 py-3 border-y border-slate-800">
            {article.author.avatar && (
              <img
                src={article.author.avatar}
                alt={article.author.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/40"
              />
            )}
            <div>
              <p className="text-sm font-bold text-white">{article.author.name}</p>
              <p className="text-xs text-slate-400">{article.author.role} • Published {new Date(article.publishedAt).toLocaleDateString()}</p>
            </div>
          </div>

          {/* Excerpt */}
          <div className="p-4 bg-slate-900/80 border-l-4 border-amber-500 rounded-r-xl italic text-slate-300 text-sm">
            {article.excerpt}
          </div>

          {/* Markdown-style content */}
          <div className="prose prose-invert max-w-none text-slate-300 text-sm sm:text-base leading-relaxed space-y-4 whitespace-pre-line font-normal">
            {article.content}
          </div>

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="pt-4 border-t border-slate-800 flex flex-wrap gap-2">
              {article.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="flex items-center gap-1 px-3 py-1 bg-slate-900 text-slate-300 rounded-lg text-xs font-medium border border-slate-800"
                >
                  <Tag className="w-3 h-3 text-amber-400" />
                  <span>#{tag}</span>
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition"
          >
            Close Article
          </button>
        </div>
      </div>
    </div>
  );
};
