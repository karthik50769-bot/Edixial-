import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Plus,
  Edit3,
  Trash2,
  Image as ImageIcon,
  Upload,
  Film,
  Gamepad2,
  Tv,
  Newspaper,
  Save,
  Check,
  X,
  Search,
  RefreshCw,
  UserPlus,
  Lock,
  ExternalLink,
  Layers,
  Sparkles,
  Sliders,
  AlertTriangle,
  FileCode2,
  Database,
  Eye,
  LogOut,
  ArrowLeft
} from 'lucide-react';
import { User } from 'firebase/auth';
import { Movie, Game, Series, Article, AdminUser, AdminSubTab } from '../../types';
import {
  signInWithGoogle,
  logOut,
  checkIsAdmin,
  addAdminByEmail,
  removeAdmin,
  getFirebaseDiagnostics,
  OWNER_EMAIL
} from '../../lib/firebase';
import {
  addMovie,
  updateMovie,
  deleteMovie,
  addGame,
  updateGame,
  deleteGame,
  addSeries,
  updateSeries,
  deleteSeries,
  addArticle,
  updateArticle,
  deleteArticle,
  pushAllToFirestore,
  resetToDefaults
} from '../../lib/dataStore';

interface AdminDashboardProps {
  currentUser: User | null;
  isAdmin: boolean;
  onReturnHome: () => void;
  movies: Movie[];
  games: Game[];
  series: Series[];
  articles: Article[];
  admins: AdminUser[];
  onOpenDiagnostics: () => void;
  preselectedEditItem?: { type: 'movie' | 'game' | 'series' | 'article'; item: any } | null;
  onClearPreselectedEdit?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  isAdmin,
  onReturnHome,
  movies,
  games,
  series,
  articles,
  admins,
  onOpenDiagnostics,
  preselectedEditItem,
  onClearPreselectedEdit
}) => {
  const [activeSubTab, setActiveSubTab] = useState<AdminSubTab>('overview');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Search in Admin
  const [searchTerm, setSearchTerm] = useState('');

  // Modals / Forms state
  const [isMovieFormOpen, setIsMovieFormOpen] = useState(false);
  const [isGameFormOpen, setIsGameFormOpen] = useState(false);
  const [isSeriesFormOpen, setIsSeriesFormOpen] = useState(false);
  const [isArticleFormOpen, setIsArticleFormOpen] = useState(false);
  
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [editingSeries, setEditingSeries] = useState<Series | null>(null);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);

  // New Admin email state
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'super_admin' | 'editor'>('super_admin');
  const [adminActionMsg, setAdminActionMsg] = useState<string | null>(null);

  // Cloud Sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Handle preselected edit passed from home
  useEffect(() => {
    if (preselectedEditItem) {
      if (preselectedEditItem.type === 'movie') {
        setEditingMovie(preselectedEditItem.item);
        setIsMovieFormOpen(true);
        setActiveSubTab('movies');
      } else if (preselectedEditItem.type === 'game') {
        setEditingGame(preselectedEditItem.item);
        setIsGameFormOpen(true);
        setActiveSubTab('games');
      } else if (preselectedEditItem.type === 'series') {
        setEditingSeries(preselectedEditItem.item);
        setIsSeriesFormOpen(true);
        setActiveSubTab('series');
      } else if (preselectedEditItem.type === 'article') {
        setEditingArticle(preselectedEditItem.item);
        setIsArticleFormOpen(true);
        setActiveSubTab('articles');
      }
      onClearPreselectedEdit?.();
    }
  }, [preselectedEditItem]);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setLoginError(null);
    const res = await signInWithGoogle();
    setIsLoggingIn(false);
    if (res.error) {
      setLoginError(res.error);
    }
  };

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;
    const res = await addAdminByEmail(newAdminEmail.trim(), newAdminRole, currentUser?.email || OWNER_EMAIL);
    setAdminActionMsg(res.message);
    setNewAdminEmail('');
    setTimeout(() => setAdminActionMsg(null), 4000);
  };

  const handleRemoveAdmin = async (email: string) => {
    if (confirm(`Revoke admin privileges for ${email}?`)) {
      await removeAdmin(email);
      setAdminActionMsg(`Admin privileges revoked for ${email}.`);
      setTimeout(() => setAdminActionMsg(null), 3000);
    }
  };

  const handlePushFirestore = async () => {
    setIsSyncing(true);
    setSyncStatus('Pushing all movies, games, series, articles & admins to Firestore...');
    const res = await pushAllToFirestore();
    setIsSyncing(false);
    if (res.error) {
      setSyncStatus(`Sync notice: ${res.error}`);
    } else {
      setSyncStatus(`Successfully synchronized ${res.count} records to Firestore project edixial-7b281!`);
    }
    setTimeout(() => setSyncStatus(null), 5000);
  };

  const diagnostics = getFirebaseDiagnostics();

  // 1. If not logged in -> Show Admin Google Sign-In Screen
  if (!currentUser) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md bg-[#0d111c] border border-amber-500/30 rounded-3xl p-8 shadow-2xl relative overflow-hidden text-center">
          
          {/* Background Glow */}
          <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl" />

          {/* Logo Badge */}
          <div className="relative mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 p-0.5 shadow-xl shadow-amber-500/25 mb-6">
            <div className="w-full h-full bg-[#090b10] rounded-[14px] flex items-center justify-center">
              <Shield className="w-8 h-8 text-amber-400" />
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white font-['Outfit'] tracking-tight">
            EDIXIAL Admin Console
          </h2>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Secure administrative control portal for movie uploads, game catalog, series management, and editorial publishing.
          </p>

          {/* Project & Authorization Status */}
          <div className="mt-6 p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-left space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Target Project:</span>
              <span className="text-amber-400 font-mono font-bold">edixial-7b281</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Authentication:</span>
              <span className="text-emerald-400 font-medium">Google Sign-In Enabled</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Primary Owner:</span>
              <span className="text-slate-300 font-mono text-[10px]">{OWNER_EMAIL}</span>
            </div>
          </div>

          {/* Error Notice if any */}
          {loginError && (
            <div className="mt-4 p-3 bg-rose-950/40 border border-rose-500/40 rounded-xl text-left text-xs text-rose-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">Authentication Notice</p>
                <p className="text-[11px] leading-relaxed text-rose-200">{loginError}</p>
                <button
                  onClick={onOpenDiagnostics}
                  className="text-[11px] text-amber-400 hover:text-amber-300 underline font-semibold mt-1 inline-block"
                >
                  Open Domain & Firebase Diagnostics →
                </button>
              </div>
            </div>
          )}

          {/* Google Sign-In Action */}
          <div className="mt-6 space-y-3">
            <button
              onClick={handleLogin}
              disabled={isLoggingIn}
              className="w-full flex items-center justify-center gap-3 py-3.5 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-sm rounded-2xl shadow-xl shadow-amber-500/30 hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50"
            >
              <Shield className="w-5 h-5 fill-black" />
              <span>{isLoggingIn ? 'Authenticating with Google...' : 'Sign In with Google (Admin)'}</span>
            </button>

            <button
              onClick={onOpenDiagnostics}
              className="w-full py-2.5 px-4 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-medium rounded-xl transition flex items-center justify-center gap-2"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Inspect Firebase Configuration & Domains</span>
            </button>
          </div>

          <div className="mt-6 pt-6 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
            <button
              onClick={onReturnHome}
              className="hover:text-slate-300 flex items-center gap-1 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Return to Website
            </button>
            <span>EDIXIAL Security Guard</span>
          </div>

        </div>
      </div>
    );
  }

  // 2. If logged in but NOT an authorized admin -> Access Denied Screen
  if (!isAdmin) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-lg bg-[#0d111c] border border-rose-500/40 rounded-3xl p-8 shadow-2xl text-center relative overflow-hidden">
          
          <div className="mx-auto w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-6">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div className="inline-block px-3 py-1 bg-rose-500/20 border border-rose-500/30 rounded-full text-xs font-bold text-rose-400 uppercase tracking-wider mb-3">
            Access Restricted
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white font-['Outfit']">
            Administrator Access Required
          </h2>

          <p className="text-sm text-slate-300 mt-3 leading-relaxed">
            You are signed in with <span className="font-semibold text-white font-mono">{currentUser.email}</span>, but this account is not registered in the EDIXIAL Administrator roster in Firestore.
          </p>

          <div className="my-6 p-4 bg-slate-950/80 border border-slate-800 rounded-2xl text-left space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Required Role:</span>
              <span className="text-amber-400 font-bold">Owner / Super Admin</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Current Status:</span>
              <span className="text-rose-400 font-bold">Unauthorized User</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Authorized Owner:</span>
              <span className="text-slate-300 font-mono text-[11px]">{OWNER_EMAIL}</span>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => logOut()}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl transition"
            >
              <LogOut className="w-4 h-4" />
              <span>Switch Google Account</span>
            </button>

            <button
              onClick={onReturnHome}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition"
            >
              <span>Return to EDIXIAL Entertainment Hub</span>
            </button>
          </div>

        </div>
      </div>
    );
  }

  // 3. Authorized Administrator Dashboard
  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Top Banner & Administrator Info Bar */}
      <div className="p-6 sm:p-8 bg-gradient-to-r from-[#0d1220] via-[#101726] to-[#0d1220] border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="relative p-3.5 bg-gradient-to-br from-amber-500 to-amber-700 rounded-2xl text-black shadow-lg shadow-amber-500/30">
            <ShieldCheck className="w-7 h-7 fill-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-white font-['Outfit'] tracking-tight">
                EDIXIAL Master Administration
              </h1>
              <span className="px-2.5 py-0.5 text-[10px] font-black tracking-widest uppercase bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-md">
                SECURE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Logged in as <span className="text-amber-300 font-semibold font-mono">{currentUser.email}</span> (Firestore Authorized Administrator)
            </p>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handlePushFirestore}
            disabled={isSyncing}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-semibold text-xs rounded-xl transition shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Push to Firestore'}</span>
          </button>

          <button
            onClick={onOpenDiagnostics}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium rounded-xl transition"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>Diagnostics</span>
          </button>

          <button
            onClick={() => logOut()}
            className="flex items-center gap-2 px-3.5 py-2 bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-xs font-semibold rounded-xl transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      {/* Sync / Notification Alert */}
      {syncStatus && (
        <div className="p-3.5 bg-cyan-950/30 border border-cyan-500/40 rounded-2xl text-xs text-cyan-200 flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{syncStatus}</span>
          </div>
          <button onClick={() => setSyncStatus(null)} className="text-cyan-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {adminActionMsg && (
        <div className="p-3.5 bg-amber-950/30 border border-amber-500/40 rounded-2xl text-xs text-amber-200 flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{adminActionMsg}</span>
          </div>
          <button onClick={() => setAdminActionMsg(null)} className="text-amber-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-white/5">
        {[
          { id: 'overview' as AdminSubTab, label: 'Dashboard Overview', icon: Layers },
          { id: 'movies' as AdminSubTab, label: `Movies (${movies.length})`, icon: Film },
          { id: 'games' as AdminSubTab, label: `Games (${games.length})`, icon: Gamepad2 },
          { id: 'series' as AdminSubTab, label: `Series (${series.length})`, icon: Tv },
          { id: 'articles' as AdminSubTab, label: `Articles (${articles.length})`, icon: Newspaper },
          { id: 'admins' as AdminSubTab, label: `Admin Team & Roles`, icon: Shield },
          { id: 'security' as AdminSubTab, label: 'Firebase Rules & Config', icon: FileCode2 }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold tracking-wide whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                  : 'bg-slate-900/90 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= TAB 1: OVERVIEW ================= */}
      {activeSubTab === 'overview' && (
        <div className="space-y-8">
          
          {/* Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-[#0f1422] border border-white/5 hover:border-amber-500/30 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Movies</span>
                <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
                  <Film className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-['Outfit']">{movies.length}</span>
                <span className="text-xs text-emerald-400 font-medium">Catalog Active</span>
              </div>
              <button
                onClick={() => {
                  setEditingMovie(null);
                  setIsMovieFormOpen(true);
                  setActiveSubTab('movies');
                }}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add New Movie
              </button>
            </div>

            <div className="p-5 bg-[#0f1422] border border-white/5 hover:border-cyan-500/30 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Games</span>
                <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                  <Gamepad2 className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-['Outfit']">{games.length}</span>
                <span className="text-xs text-cyan-400 font-medium">Next-Gen Catalog</span>
              </div>
              <button
                onClick={() => {
                  setEditingGame(null);
                  setIsGameFormOpen(true);
                  setActiveSubTab('games');
                }}
                className="mt-3 text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add New Game
              </button>
            </div>

            <div className="p-5 bg-[#0f1422] border border-white/5 hover:border-purple-500/30 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Series</span>
                <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl">
                  <Tv className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-['Outfit']">{series.length}</span>
                <span className="text-xs text-purple-400 font-medium">TV Catalog</span>
              </div>
              <button
                onClick={() => {
                  setEditingSeries(null);
                  setIsSeriesFormOpen(true);
                  setActiveSubTab('series');
                }}
                className="mt-3 text-xs text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add New Series
              </button>
            </div>

            <div className="p-5 bg-[#0f1422] border border-white/5 hover:border-emerald-500/30 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Articles Published</span>
                <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                  <Newspaper className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-['Outfit']">{articles.length}</span>
                <span className="text-xs text-emerald-400 font-medium">Editorials Active</span>
              </div>
              <button
                onClick={() => {
                  setEditingArticle(null);
                  setIsArticleFormOpen(true);
                  setActiveSubTab('articles');
                }}
                className="mt-3 text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Write Article
              </button>
            </div>
          </div>

          {/* Quick Management Suite Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Quick Content Creator Box */}
            <div className="p-6 bg-[#0f1422] border border-white/5 rounded-3xl space-y-4">
              <h3 className="text-lg font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Plus className="w-5 h-5 text-amber-400" />
                <span>Quick Content Creation</span>
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Add fresh content instantly to the EDIXIAL portal. Changes sync automatically to Firestore and local databases.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    setEditingMovie(null);
                    setIsMovieFormOpen(true);
                    setActiveSubTab('movies');
                  }}
                  className="p-4 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl text-left space-y-1 transition group"
                >
                  <Film className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-white">Add Movie</div>
                  <div className="text-[11px] text-slate-500">Upload poster, duration & cast</div>
                </button>

                <button
                  onClick={() => {
                    setEditingGame(null);
                    setIsGameFormOpen(true);
                    setActiveSubTab('games');
                  }}
                  className="p-4 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl text-left space-y-1 transition group"
                >
                  <Gamepad2 className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-white">Add Game</div>
                  <div className="text-[11px] text-slate-500">Specs, platforms & links</div>
                </button>

                <button
                  onClick={() => {
                    setEditingSeries(null);
                    setIsSeriesFormOpen(true);
                    setActiveSubTab('series');
                  }}
                  className="p-4 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl text-left space-y-1 transition group"
                >
                  <Tv className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-white">Add Series</div>
                  <div className="text-[11px] text-slate-500">Seasons, episodes & network</div>
                </button>

                <button
                  onClick={() => {
                    setEditingArticle(null);
                    setIsArticleFormOpen(true);
                    setActiveSubTab('articles');
                  }}
                  className="p-4 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl text-left space-y-1 transition group"
                >
                  <Newspaper className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-white">Publish Article</div>
                  <div className="text-[11px] text-slate-500">News, patch notes & reviews</div>
                </button>
              </div>
            </div>

            {/* Cloud & Project Status */}
            <div className="p-6 bg-[#0f1422] border border-white/5 rounded-3xl space-y-4">
              <h3 className="text-lg font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Database className="w-5 h-5 text-cyan-400" />
                <span>Cloud & Security Status</span>
              </h3>

              <div className="p-4 bg-slate-950/80 border border-slate-800/80 rounded-2xl space-y-3 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Firebase Project ID:</span>
                  <span className="text-amber-400 font-mono font-bold">{diagnostics.projectId}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Auth Domain:</span>
                  <span className="text-slate-200 font-mono text-[11px]">{diagnostics.authDomain}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Authorized Super Owner:</span>
                  <span className="text-purple-300 font-mono text-[11px]">{OWNER_EMAIL}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Firestore Rules:</span>
                  <span className="text-emerald-400 font-bold">Configured in firestore.rules</span>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-1">
                <button
                  onClick={onOpenDiagnostics}
                  className="flex-1 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold rounded-xl transition"
                >
                  Netlify Domain Diagnostic
                </button>
                <button
                  onClick={handlePushFirestore}
                  disabled={isSyncing}
                  className="flex-1 py-2.5 px-4 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-semibold rounded-xl transition"
                >
                  Sync Database
                </button>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ================= TAB 2: MOVIES MANAGER ================= */}
      {activeSubTab === 'movies' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Film className="w-5 h-5 text-amber-400" />
                <span>Movie Catalog Management</span>
              </h2>
              <p className="text-xs text-slate-400">Add new movies, upload posters, edit movie titles, change artwork, or delete content.</p>
            </div>

            <button
              onClick={() => {
                setEditingMovie(null);
                setIsMovieFormOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Movie</span>
            </button>
          </div>

          {/* Table / Cards List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {movies.map((movie) => (
              <div
                key={movie.id}
                className="flex bg-[#0f1422] border border-white/5 hover:border-amber-500/30 rounded-2xl overflow-hidden shadow-lg p-3 gap-3"
              >
                {/* Poster */}
                <div className="w-20 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 relative group">
                  <img
                    src={movie.posterUrl}
                    alt={movie.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Info */}
                <div className="flex flex-col justify-between flex-grow min-w-0">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-amber-400 font-semibold">{movie.releaseYear} • {movie.duration}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-bold">★ {movie.rating.toFixed(1)}</span>
                    </div>
                    <h4 className="text-sm font-bold text-white truncate mt-1">{movie.title}</h4>
                    <p className="text-[11px] text-slate-400 truncate">{movie.genres?.join(', ')}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => {
                        setEditingMovie(movie);
                        setIsMovieFormOpen(true);
                      }}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-xs font-semibold transition"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Edit / Poster
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete "${movie.title}"?`)) {
                          await deleteMovie(movie.id);
                        }
                      }}
                      className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 rounded-lg transition"
                      title="Delete Movie"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 3: GAMES MANAGER ================= */}
      {activeSubTab === 'games' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-cyan-400" />
                <span>Games Catalog Management</span>
              </h2>
              <p className="text-xs text-slate-400">Add next-gen games, edit platforms, upload covers, and manage game specs.</p>
            </div>

            <button
              onClick={() => {
                setEditingGame(null);
                setIsGameFormOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-400 hover:to-cyan-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-cyan-500/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Game</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {games.map((game) => (
              <div
                key={game.id}
                className="flex bg-[#0f1422] border border-white/5 hover:border-cyan-500/30 rounded-2xl overflow-hidden shadow-lg p-3 gap-3"
              >
                <div className="w-20 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
                  <img
                    src={game.posterUrl}
                    alt={game.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex flex-col justify-between flex-grow min-w-0">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-cyan-400 font-semibold">{game.developer}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-bold">★ {game.rating.toFixed(1)}</span>
                    </div>
                    <h4 className="text-sm font-bold text-white truncate mt-1">{game.title}</h4>
                    <p className="text-[11px] text-slate-400 truncate">{game.platforms?.join(', ')}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => {
                        setEditingGame(game);
                        setIsGameFormOpen(true);
                      }}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 rounded-lg text-xs font-semibold transition"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Edit / Cover
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete "${game.title}"?`)) {
                          await deleteGame(game.id);
                        }
                      }}
                      className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 rounded-lg transition"
                      title="Delete Game"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 4: SERIES MANAGER ================= */}
      {activeSubTab === 'series' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Tv className="w-5 h-5 text-purple-400" />
                <span>Television & Series Management</span>
              </h2>
              <p className="text-xs text-slate-400">Add original TV shows, configure seasons/episodes, posters, and streaming networks.</p>
            </div>

            <button
              onClick={() => {
                setEditingSeries(null);
                setIsSeriesFormOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-400 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-purple-500/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Series</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {series.map((s) => (
              <div
                key={s.id}
                className="flex bg-[#0f1422] border border-white/5 hover:border-purple-500/30 rounded-2xl overflow-hidden shadow-lg p-3 gap-3"
              >
                <div className="w-20 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
                  <img
                    src={s.posterUrl}
                    alt={s.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex flex-col justify-between flex-grow min-w-0">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-purple-400 font-semibold">{s.network || 'Stream'} • S{s.totalSeasons}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-bold">★ {s.rating.toFixed(1)}</span>
                    </div>
                    <h4 className="text-sm font-bold text-white truncate mt-1">{s.title}</h4>
                    <p className="text-[11px] text-slate-400 truncate">{s.genres?.join(', ')}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => {
                        setEditingSeries(s);
                        setIsSeriesFormOpen(true);
                      }}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 rounded-lg text-xs font-semibold transition"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Edit / Poster
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete "${s.title}"?`)) {
                          await deleteSeries(s.id);
                        }
                      }}
                      className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 rounded-lg transition"
                      title="Delete Series"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 5: ARTICLES PUBLISHER ================= */}
      {activeSubTab === 'articles' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Newspaper className="w-5 h-5 text-emerald-400" />
                <span>Publish Articles, Reviews & Patch Updates</span>
              </h2>
              <p className="text-xs text-slate-400">Author exclusive stories, game reviews, cinematic critiques, and site announcements.</p>
            </div>

            <button
              onClick={() => {
                setEditingArticle(null);
                setIsArticleFormOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Write New Article</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {articles.map((art) => (
              <div
                key={art.id}
                className="bg-[#0f1422] border border-white/5 rounded-2xl overflow-hidden p-4 space-y-3"
              >
                <div className="flex gap-3">
                  <img
                    src={art.coverUrl}
                    alt={art.title}
                    referrerPolicy="no-referrer"
                    className="w-24 h-16 rounded-xl object-cover shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                      {art.category}
                    </span>
                    <h4 className="text-sm font-bold text-white line-clamp-1 mt-1">{art.title}</h4>
                    <p className="text-xs text-slate-400 line-clamp-1">{art.excerpt}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-slate-400">
                  <span>Author: <strong className="text-slate-200">{art.author.name}</strong></span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setEditingArticle(art);
                        setIsArticleFormOpen(true);
                      }}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Edit
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete article "${art.title}"?`)) {
                          await deleteArticle(art.id);
                        }
                      }}
                      className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 rounded-lg transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 6: ADMIN TEAM & ROLES ================= */}
      {activeSubTab === 'admins' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left: Add New Admin Form */}
            <div className="bg-[#0f1422] border border-white/5 rounded-3xl p-6 space-y-4">
              <h3 className="text-base font-bold text-white font-['Outfit'] flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-amber-400" />
                <span>Grant Administrator Access</span>
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Add an email to authorize them for EDIXIAL Admin Dashboard access via Google Sign-In. Permissions are stored in Firestore under <code className="text-amber-400">/admins</code>.
              </p>

              <form onSubmit={handleAddAdmin} className="space-y-4 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Administrator Google Email</label>
                  <input
                    type="email"
                    required
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    placeholder="colleague@gmail.com"
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Administrative Role</label>
                  <select
                    value={newAdminRole}
                    onChange={(e) => setNewAdminRole(e.target.value as any)}
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="super_admin">Super Administrator (Full Edit/Delete/Upload)</option>
                    <option value="editor">Editor (Add & Edit Content)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Authorize Administrator</span>
                </button>
              </form>
            </div>

            {/* Right 2 cols: Authorized Admins List */}
            <div className="lg:col-span-2 bg-[#0f1422] border border-white/5 rounded-3xl p-6 space-y-4">
              <h3 className="text-base font-bold text-white font-['Outfit'] flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <span>Authorized Administrator Roster</span>
              </h3>

              <div className="space-y-3">
                {/* Primary Owner Card */}
                <div className="p-4 bg-slate-950/90 border border-amber-500/40 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold text-sm">
                      👑
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white font-mono">{OWNER_EMAIL}</span>
                        <span className="px-2 py-0.5 bg-amber-500 text-black text-[9px] font-black uppercase rounded">
                          Primary Owner
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">Permanent Root Administrator • All Permissions</p>
                    </div>
                  </div>
                  <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Active
                  </span>
                </div>

                {/* Other Authorized Admins */}
                {admins.filter(a => a.email.toLowerCase() !== OWNER_EMAIL.toLowerCase()).map((admin) => (
                  <div
                    key={admin.email}
                    className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white font-mono">{admin.email}</span>
                        <span className="px-2 py-0.5 bg-slate-800 text-amber-400 text-[9px] font-bold uppercase rounded">
                          {admin.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">Added {new Date(admin.addedAt).toLocaleDateString()}</p>
                    </div>

                    <button
                      onClick={() => handleRemoveAdmin(admin.email)}
                      className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition"
                      title="Revoke Admin Access"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ================= TAB 7: FIREBASE RULES & SECURITY ================= */}
      {activeSubTab === 'security' && (
        <div className="space-y-6">
          <div className="bg-[#0f1422] border border-white/5 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white font-['Outfit'] flex items-center gap-2">
                  <FileCode2 className="w-5 h-5 text-amber-400" />
                  <span>Firestore Security Rules (firestore.rules)</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Protecting public read access for visitors while locking all write, edit, upload, and delete permissions strictly to authorized administrators.
                </p>
              </div>

              <a
                href={`https://console.firebase.google.com/project/edixial-7b281/firestore/rules`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 text-black font-bold text-xs rounded-xl hover:bg-amber-400 transition"
              >
                <span>Deploy in Firebase Console</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <pre className="p-4 bg-slate-950 border border-slate-800 rounded-2xl text-xs font-mono text-amber-300/90 overflow-x-auto leading-relaxed">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    function isSignedIn() {
      return request.auth != null;
    }

    function isAdmin() {
      return isSignedIn() && (
        exists(/databases/$(database)/documents/admins/$(request.auth.uid)) ||
        exists(/databases/$(database)/documents/admins/$(request.auth.token.email)) ||
        (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin') ||
        request.auth.token.email == '${OWNER_EMAIL}'
      );
    }

    // Public read, Admin write
    match /movies/{movieId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();
    }

    match /games/{gameId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();
    }

    match /series/{seriesId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();
    }

    match /articles/{articleId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();
    }

    match /admins/{adminId} {
      allow read: if isSignedIn();
      allow write: if isAdmin();
    }
  }
}`}
            </pre>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT MOVIE ================= */}
      {isMovieFormOpen && (
        <MovieFormModal
          isOpen={isMovieFormOpen}
          onClose={() => {
            setIsMovieFormOpen(false);
            setEditingMovie(null);
          }}
          movie={editingMovie}
          onSave={async (movieData) => {
            if (editingMovie) {
              await updateMovie(editingMovie.id, movieData);
            } else {
              await addMovie(movieData);
            }
            setIsMovieFormOpen(false);
            setEditingMovie(null);
          }}
        />
      )}

      {/* ================= MODAL: ADD / EDIT GAME ================= */}
      {isGameFormOpen && (
        <GameFormModal
          isOpen={isGameFormOpen}
          onClose={() => {
            setIsGameFormOpen(false);
            setEditingGame(null);
          }}
          game={editingGame}
          onSave={async (gameData) => {
            if (editingGame) {
              await updateGame(editingGame.id, gameData);
            } else {
              await addGame(gameData);
            }
            setIsGameFormOpen(false);
            setEditingGame(null);
          }}
        />
      )}

      {/* ================= MODAL: ADD / EDIT SERIES ================= */}
      {isSeriesFormOpen && (
        <SeriesFormModal
          isOpen={isSeriesFormOpen}
          onClose={() => {
            setIsSeriesFormOpen(false);
            setEditingSeries(null);
          }}
          series={editingSeries}
          onSave={async (seriesData) => {
            if (editingSeries) {
              await updateSeries(editingSeries.id, seriesData);
            } else {
              await addSeries(seriesData);
            }
            setIsSeriesFormOpen(false);
            setEditingSeries(null);
          }}
        />
      )}

      {/* ================= MODAL: ADD / EDIT ARTICLE ================= */}
      {isArticleFormOpen && (
        <ArticleFormModal
          isOpen={isArticleFormOpen}
          onClose={() => {
            setIsArticleFormOpen(false);
            setEditingArticle(null);
          }}
          article={editingArticle}
          currentUser={currentUser}
          onSave={async (articleData) => {
            if (editingArticle) {
              await updateArticle(editingArticle.id, articleData);
            } else {
              await addArticle(articleData);
            }
            setIsArticleFormOpen(false);
            setEditingArticle(null);
          }}
        />
      )}

    </div>
  );
};

// =================== MOVIE FORM MODAL ===================
const MovieFormModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  movie: Movie | null;
  onSave: (data: any) => Promise<void>;
}> = ({ isOpen, onClose, movie, onSave }) => {
  const [title, setTitle] = useState(movie?.title || '');
  const [synopsis, setSynopsis] = useState(movie?.synopsis || '');
  const [posterUrl, setPosterUrl] = useState(movie?.posterUrl || '');
  const [backdropUrl, setBackdropUrl] = useState(movie?.backdropUrl || '');
  const [releaseYear, setReleaseYear] = useState(movie?.releaseYear || 2026);
  const [duration, setDuration] = useState(movie?.duration || '2h 15m');
  const [rating, setRating] = useState(movie?.rating || 8.5);
  const [genres, setGenres] = useState(movie?.genres ? movie.genres.join(', ') : 'Action, Sci-Fi');
  const [director, setDirector] = useState(movie?.director || '');
  const [cast, setCast] = useState(movie?.cast ? movie.cast.join(', ') : '');
  const [trailerUrl, setTrailerUrl] = useState(movie?.trailerUrl || '');
  const [language, setLanguage] = useState(movie?.language || 'English');
  const [status, setStatus] = useState<any>(movie?.status || 'In Theaters');
  const [featured, setFeatured] = useState(movie?.featured || false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  // File upload handler (converts image to base64 data URL for direct instant usage)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'poster' | 'backdrop') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (target === 'poster') setPosterUrl(reader.result as string);
        if (target === 'backdrop') setBackdropUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await onSave({
      title: title.trim(),
      synopsis: synopsis.trim(),
      posterUrl: posterUrl.trim() || 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80',
      backdropUrl: backdropUrl.trim() || posterUrl.trim(),
      releaseYear: Number(releaseYear),
      duration: duration.trim(),
      rating: Number(rating),
      genres: genres.split(',').map(g => g.trim()).filter(Boolean),
      director: director.trim(),
      cast: cast.split(',').map(c => c.trim()).filter(Boolean),
      trailerUrl: trailerUrl.trim(),
      language: language.trim(),
      status,
      featured
    });
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#0d111c] border border-amber-500/30 rounded-3xl p-6 sm:p-8 text-slate-200 my-auto shadow-2xl">
        
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl">
              <Film className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-['Outfit']">
                {movie ? 'Edit Movie & Change Poster' : 'Add New Movie to EDIXIAL'}
              </h3>
              <p className="text-xs text-slate-400">Provide movie details, upload poster artwork, and set streaming trailer.</p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-6 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Movie Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Cyberpunk: Neon Odyssey"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Director</label>
              <input
                type="text"
                value={director}
                onChange={(e) => setDirector(e.target.value)}
                placeholder="e.g. Denis Villeneuve"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Release Year</label>
              <input
                type="number"
                value={releaseYear}
                onChange={(e) => setReleaseYear(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Duration (e.g. 2h 24m)</label>
              <input
                type="text"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="2h 15m"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Rating (1 to 10)</label>
              <input
                type="number"
                step="0.1"
                min="1"
                max="10"
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Genres (Comma separated)</label>
              <input
                type="text"
                value={genres}
                onChange={(e) => setGenres(e.target.value)}
                placeholder="Action, Sci-Fi, Cyberpunk, Thriller"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Cast Members (Comma separated)</label>
              <input
                type="text"
                value={cast}
                onChange={(e) => setCast(e.target.value)}
                placeholder="Keanu Reeves, Ana de Armas, Oscar Isaac"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Poster Upload & URL */}
            <div className="sm:col-span-2 p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3">
              <label className="block text-amber-400 font-bold">Movie Poster Artwork</label>
              
              <div className="flex flex-col sm:flex-row gap-4 items-start">
                {posterUrl && (
                  <img
                    src={posterUrl}
                    alt="Poster Preview"
                    referrerPolicy="no-referrer"
                    className="w-24 h-36 object-cover rounded-xl border border-amber-500/40 shrink-0"
                  />
                )}

                <div className="flex-grow space-y-2 w-full">
                  <div>
                    <span className="text-slate-400 block mb-1">Poster Image URL:</span>
                    <input
                      type="url"
                      value={posterUrl}
                      onChange={(e) => setPosterUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <span className="text-slate-400 block mb-1">Or Upload Local Image File:</span>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl cursor-pointer w-fit font-medium transition">
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>Choose Poster File</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, 'poster')}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Trailer Video Stream URL (YouTube or MP4)</label>
              <input
                type="url"
                value={trailerUrl}
                onChange={(e) => setTrailerUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Synopsis</label>
              <textarea
                rows={3}
                required
                value={synopsis}
                onChange={(e) => setSynopsis(e.target.value)}
                placeholder="Enter compelling movie description..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none"
              >
                <option value="In Theaters">In Theaters</option>
                <option value="Released">Released</option>
                <option value="Coming Soon">Coming Soon</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-6">
              <input
                type="checkbox"
                id="featMovie"
                checked={featured}
                onChange={(e) => setFeatured(e.target.checked)}
                className="w-4 h-4 rounded text-amber-500 focus:ring-0"
              />
              <label htmlFor="featMovie" className="text-slate-300 font-semibold cursor-pointer">
                Feature on Homepage Hero Banner
              </label>
            </div>

          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : 'Save Movie'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

// =================== GAME FORM MODAL ===================
const GameFormModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  game: Game | null;
  onSave: (data: any) => Promise<void>;
}> = ({ isOpen, onClose, game, onSave }) => {
  const [title, setTitle] = useState(game?.title || '');
  const [synopsis, setSynopsis] = useState(game?.synopsis || '');
  const [posterUrl, setPosterUrl] = useState(game?.posterUrl || '');
  const [releaseDate, setReleaseDate] = useState(game?.releaseDate || 'Available Now');
  const [developer, setDeveloper] = useState(game?.developer || '');
  const [publisher, setPublisher] = useState(game?.publisher || '');
  const [platforms, setPlatforms] = useState(game?.platforms ? game.platforms.join(', ') : 'PC, PS5, Xbox Series X');
  const [genres, setGenres] = useState(game?.genres ? game.genres.join(', ') : 'Action RPG, Open World');
  const [rating, setRating] = useState(game?.rating || 9.2);
  const [trailerUrl, setTrailerUrl] = useState(game?.trailerUrl || '');
  const [featured, setFeatured] = useState(game?.featured || false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPosterUrl(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await onSave({
      title: title.trim(),
      synopsis: synopsis.trim(),
      posterUrl: posterUrl.trim() || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      backdropUrl: posterUrl.trim(),
      releaseDate: releaseDate.trim(),
      developer: developer.trim(),
      publisher: publisher.trim(),
      platforms: platforms.split(',').map(p => p.trim()).filter(Boolean),
      genres: genres.split(',').map(g => g.trim()).filter(Boolean),
      rating: Number(rating),
      trailerUrl: trailerUrl.trim(),
      featured
    });
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-[#0d111c] border border-cyan-500/30 rounded-3xl p-6 sm:p-8 text-slate-200 my-auto shadow-2xl">
        
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-500/20 text-cyan-400 rounded-xl">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-['Outfit']">
                {game ? 'Edit Game & Cover' : 'Add New Game'}
              </h3>
              <p className="text-xs text-slate-400">Configure platforms, developer, system specs and game trailer.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-6 text-xs">
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Game Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Cyberpunk 2077: Phantom Liberty"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500 text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Developer</label>
              <input
                type="text"
                value={developer}
                onChange={(e) => setDeveloper(e.target.value)}
                placeholder="e.g. CD PROJEKT RED"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Release Date</label>
              <input
                type="text"
                value={releaseDate}
                onChange={(e) => setReleaseDate(e.target.value)}
                placeholder="Available Now"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Platforms (Comma separated)</label>
            <input
              type="text"
              value={platforms}
              onChange={(e) => setPlatforms(e.target.value)}
              placeholder="PC, PS5, Xbox Series X"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Cover */}
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
            <label className="block text-cyan-400 font-bold">Game Cover Art</label>
            <div className="flex gap-4 items-center">
              {posterUrl && <img src={posterUrl} alt="Cover" className="w-16 h-20 object-cover rounded-lg border border-cyan-500/40" />}
              <div className="space-y-1.5 flex-grow">
                <input
                  type="url"
                  value={posterUrl}
                  onChange={(e) => setPosterUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-white"
                />
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg cursor-pointer">
                  <Upload className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Upload Image</span>
                  <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Trailer Stream URL</label>
            <input
              type="url"
              value={trailerUrl}
              onChange={(e) => setTrailerUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Synopsis</label>
            <textarea
              rows={3}
              required
              value={synopsis}
              onChange={(e) => setSynopsis(e.target.value)}
              placeholder="Game description..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl">Cancel</button>
            <button type="submit" disabled={isSubmitting} className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-black font-extrabold rounded-xl">
              {isSubmitting ? 'Saving...' : 'Save Game'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// =================== SERIES FORM MODAL ===================
const SeriesFormModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  series: Series | null;
  onSave: (data: any) => Promise<void>;
}> = ({ isOpen, onClose, series, onSave }) => {
  const [title, setTitle] = useState(series?.title || '');
  const [synopsis, setSynopsis] = useState(series?.synopsis || '');
  const [posterUrl, setPosterUrl] = useState(series?.posterUrl || '');
  const [releaseYear, setReleaseYear] = useState(series?.releaseYear || 2025);
  const [totalSeasons, setTotalSeasons] = useState(series?.totalSeasons || 1);
  const [totalEpisodes, setTotalEpisodes] = useState(series?.totalEpisodes || 10);
  const [genres, setGenres] = useState(series?.genres ? series.genres.join(', ') : 'Drama, Sci-Fi');
  const [creator, setCreator] = useState(series?.creator || '');
  const [network, setNetwork] = useState(series?.network || 'Streaming');
  const [rating, setRating] = useState(series?.rating || 9.0);
  const [status, setStatus] = useState<any>(series?.status || 'Ongoing');
  const [trailerUrl, setTrailerUrl] = useState(series?.trailerUrl || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await onSave({
      title: title.trim(),
      synopsis: synopsis.trim(),
      posterUrl: posterUrl.trim() || 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=800&q=80',
      releaseYear: Number(releaseYear),
      totalSeasons: Number(totalSeasons),
      totalEpisodes: Number(totalEpisodes),
      genres: genres.split(',').map(g => g.trim()).filter(Boolean),
      creator: creator.trim(),
      network: network.trim(),
      rating: Number(rating),
      status,
      trailerUrl: trailerUrl.trim()
    });
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-[#0d111c] border border-purple-500/30 rounded-3xl p-6 sm:p-8 text-slate-200 my-auto shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-purple-500/20 text-purple-400 rounded-xl">
              <Tv className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-['Outfit']">{series ? 'Edit Series' : 'Add New Series'}</h3>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-6 text-xs">
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Series Title *</label>
            <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Seasons</label>
              <input type="number" value={totalSeasons} onChange={(e) => setTotalSeasons(Number(e.target.value))} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Episodes</label>
              <input type="number" value={totalEpisodes} onChange={(e) => setTotalEpisodes(Number(e.target.value))} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Network / Platform</label>
              <input type="text" value={network} onChange={(e) => setNetwork(e.target.value)} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Poster URL</label>
            <input type="url" value={posterUrl} onChange={(e) => setPosterUrl(e.target.value)} placeholder="https://..." className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Synopsis</label>
            <textarea rows={3} required value={synopsis} onChange={(e) => setSynopsis(e.target.value)} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl">Cancel</button>
            <button type="submit" disabled={isSubmitting} className="px-6 py-2 bg-gradient-to-r from-purple-500 to-purple-600 text-white font-extrabold rounded-xl">
              {isSubmitting ? 'Saving...' : 'Save Series'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// =================== ARTICLE FORM MODAL ===================
const ArticleFormModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  article: Article | null;
  currentUser: User | null;
  onSave: (data: any) => Promise<void>;
}> = ({ isOpen, onClose, article, currentUser, onSave }) => {
  const [title, setTitle] = useState(article?.title || '');
  const [excerpt, setExcerpt] = useState(article?.excerpt || '');
  const [content, setContent] = useState(article?.content || '');
  const [category, setCategory] = useState<any>(article?.category || 'News');
  const [coverUrl, setCoverUrl] = useState(article?.coverUrl || '');
  const [readTime, setReadTime] = useState(article?.readTime || '5 min read');
  const [tags, setTags] = useState(article?.tags ? article.tags.join(', ') : 'Cinema, Gaming, Update');
  const [featured, setFeatured] = useState(article?.featured || false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await onSave({
      title: title.trim(),
      slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      excerpt: excerpt.trim(),
      content: content.trim(),
      category,
      coverUrl: coverUrl.trim() || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
      author: article?.author || {
        name: currentUser?.displayName || 'EDIXIAL Editorial',
        email: currentUser?.email || OWNER_EMAIL,
        role: 'Senior Editor'
      },
      publishedAt: article?.publishedAt || new Date().toISOString(),
      readTime: readTime.trim(),
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      featured
    });
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#0d111c] border border-emerald-500/30 rounded-3xl p-6 sm:p-8 text-slate-200 my-auto shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <Newspaper className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-['Outfit']">{article ? 'Edit Article' : 'Write & Publish Article'}</h3>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-6 text-xs">
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Article Headline *</label>
            <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Headline..." className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-sm" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Category</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white">
                <option value="News">News</option>
                <option value="Review">Review</option>
                <option value="Feature">Feature</option>
                <option value="Exclusive">Exclusive</option>
                <option value="Patch Notes">Patch Notes</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Read Time (e.g. 5 min read)</label>
              <input type="text" value={readTime} onChange={(e) => setReadTime(e.target.value)} className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Cover Image URL</label>
            <input type="url" value={coverUrl} onChange={(e) => setCoverUrl(e.target.value)} placeholder="https://..." className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Short Excerpt (Lead)</label>
            <input type="text" required value={excerpt} onChange={(e) => setExcerpt(e.target.value)} placeholder="1-2 sentences summarizing story..." className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Full Article Body (Markdown supported)</label>
            <textarea rows={6} required value={content} onChange={(e) => setContent(e.target.value)} placeholder="Write full article here..." className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-xs" />
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Tags (Comma separated)</label>
            <input type="text" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Cinema, Gaming, VFX" className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white" />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl">Cancel</button>
            <button type="submit" disabled={isSubmitting} className="px-6 py-2 bg-gradient-to-r from-emerald-500 to-emerald-600 text-black font-extrabold rounded-xl">
              {isSubmitting ? 'Publishing...' : 'Publish Article'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
