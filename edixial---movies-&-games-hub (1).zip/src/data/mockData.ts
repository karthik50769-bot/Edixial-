import { Movie, Game, Series, Article, AdminUser } from '../types';
import { OWNER_EMAIL } from '../lib/firebase';

export const INITIAL_MOVIES: Movie[] = [
  {
    id: 'm1',
    title: 'Cyberpunk: Neon Odyssey',
    originalTitle: 'Neon Odyssey 2099',
    synopsis: 'In a rain-drenched megacity ruled by rogue AI syndicates, a cybernetically enhanced mercenary unravels an encrypted conspiracy that threatens human consciousness itself.',
    posterUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2026,
    duration: '2h 24m',
    rating: 9.1,
    genres: ['Sci-Fi', 'Action', 'Cyberpunk', 'Thriller'],
    director: 'Denis Villeneuve',
    cast: ['Keanu Reeves', 'Ana de Armas', 'Oscar Isaac', 'Florence Pugh'],
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    language: 'English',
    status: 'In Theaters',
    ageRating: 'PG-13',
    featured: true,
    views: 142500,
    tags: ['Blockbuster', '4K HDR', 'Sci-Fi Epic', 'IMAX'],
    createdAt: '2026-01-15T00:00:00Z',
    updatedAt: '2026-02-20T00:00:00Z'
  },
  {
    id: 'm2',
    title: 'Dune: The Prophecy Reborn',
    synopsis: 'Centuries following Paul Atreides, new factions rise across Arrakis to seize control of the spice melange and unlock the ancient ancestral memory deep within the desert sands.',
    posterUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2025,
    duration: '2h 45m',
    rating: 8.9,
    genres: ['Adventure', 'Drama', 'Sci-Fi'],
    director: 'Denis Villeneuve',
    cast: ['Timothée Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Josh Brolin'],
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    language: 'English',
    status: 'Released',
    ageRating: 'PG-13',
    featured: true,
    views: 98000,
    tags: ['Sci-Fi', 'Desert Epic', 'Masterpiece'],
    createdAt: '2025-11-10T00:00:00Z',
    updatedAt: '2026-01-05T00:00:00Z'
  },
  {
    id: 'm3',
    title: 'Shadows of Gotham: Knightfall',
    synopsis: 'A ruthless underworld cartel unleashes chemical warfare across Gotham, forcing the Dark Knight to forge dangerous alliances with old adversaries.',
    posterUrl: 'https://images.unsplash.com/photo-1509281373149-e957c6296406?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2026,
    duration: '2h 38m',
    rating: 9.3,
    genres: ['Action', 'Crime', 'Drama', 'Mystery'],
    director: 'Matt Reeves',
    cast: ['Robert Pattinson', 'Barry Keoghan', 'Zoë Kravitz', 'Colin Farrell'],
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    language: 'English',
    status: 'Coming Soon',
    ageRating: 'R',
    featured: true,
    views: 215000,
    tags: ['Dark Knight', 'Noir', 'Vigilante'],
    createdAt: '2026-02-01T00:00:00Z',
    updatedAt: '2026-02-15T00:00:00Z'
  },
  {
    id: 'm4',
    title: 'Interstellar Void: Chronos',
    synopsis: 'When a quantum rift opens near Jupiter, an exploratory fleet must traverse temporal distortions to prevent the collapse of Earth’s solar orbit.',
    posterUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2025,
    duration: '2h 19m',
    rating: 8.7,
    genres: ['Sci-Fi', 'Mystery', 'Adventure'],
    director: 'Christopher Nolan',
    cast: ['Cillian Murphy', 'Jessica Chastain', 'Matthew McConaughey'],
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    language: 'English',
    status: 'Released',
    ageRating: 'PG-13',
    featured: false,
    views: 87400,
    tags: ['Space', 'Time Travel', 'Quantum'],
    createdAt: '2025-10-04T00:00:00Z',
    updatedAt: '2025-12-18T00:00:00Z'
  },
  {
    id: 'm5',
    title: 'Eldritch: The Old Gods Awakened',
    synopsis: 'An arctic research team in Greenland accidentally awakens a primordial cosmic entity locked deep within the subterranean ice shelf.',
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2026,
    duration: '1h 58m',
    rating: 8.4,
    genres: ['Horror', 'Mystery', 'Sci-Fi'],
    director: 'Guillermo del Toro',
    cast: ['Mads Mikkelsen', 'Rebecca Hall', 'Willem Dafoe'],
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    language: 'English',
    status: 'In Theaters',
    ageRating: 'R',
    featured: false,
    views: 64200,
    tags: ['Cosmic Horror', 'Lovecraftian'],
    createdAt: '2026-01-20T00:00:00Z',
    updatedAt: '2026-02-10T00:00:00Z'
  }
];

export const INITIAL_GAMES: Game[] = [
  {
    id: 'g1',
    title: 'Cyberpunk 2077: Phantom Liberty 2.0',
    synopsis: 'Return to the neon-lit combat zone of Dogtown as cyber-agent V in a high-stakes espionage thriller with next-gen Ray Tracing Overdrive.',
    posterUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1600&q=80',
    releaseDate: 'Available Now',
    developer: 'CD PROJEKT RED',
    publisher: 'CD PROJEKT',
    platforms: ['PC', 'PS5', 'Xbox Series X'],
    genres: ['Action RPG', 'Open World', 'Cyberpunk', 'FPS'],
    rating: 9.6,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    downloadUrl: 'https://store.steampowered.com',
    screenshots: [
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80'
    ],
    systemRequirements: {
      os: 'Windows 11 (64-bit)',
      processor: 'Intel Core i7-12700K or AMD Ryzen 7 7800X3D',
      memory: '32 GB RAM',
      graphics: 'NVIDIA GeForce RTX 4080 (16GB) or AMD Radeon RX 7900 XTX',
      storage: '120 GB SSD NVMe'
    },
    featured: true,
    tags: ['Ray Tracing', 'Story Rich', 'Open World'],
    createdAt: '2025-08-10T00:00:00Z',
    updatedAt: '2026-02-18T00:00:00Z'
  },
  {
    id: 'g2',
    title: 'Elden Ring: Shadow of the Erdtree',
    synopsis: 'Guided by Empyrean Miquella, players are summoned to the Land of Shadow, a place obscured by the Erdtree where the goddess Marika first set foot.',
    posterUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1600&q=80',
    releaseDate: 'Available Now',
    developer: 'FromSoftware Inc.',
    publisher: 'Bandai Namco Entertainment',
    platforms: ['PC', 'PS5', 'PS4', 'Xbox Series X'],
    genres: ['Action RPG', 'Souls-like', 'Dark Fantasy', 'Open World'],
    rating: 9.8,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    downloadUrl: 'https://store.steampowered.com',
    featured: true,
    tags: ['GOTY', 'Masterpiece', 'Challenging'],
    createdAt: '2025-06-21T00:00:00Z',
    updatedAt: '2026-01-12T00:00:00Z'
  },
  {
    id: 'g3',
    title: 'Ghost of Yōtei',
    synopsis: 'Set in 1603 Japan around the majestic Mount Yōtei in Hokkaido, step into the boots of Atsu on a breathtaking quest of vengeance and destiny.',
    posterUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?auto=format&fit=crop&w=1600&q=80',
    releaseDate: 'Late 2025 / 2026',
    developer: 'Sucker Punch Productions',
    publisher: 'Sony Interactive Entertainment',
    platforms: ['PS5', 'PC'],
    genres: ['Action-Adventure', 'Samurai', 'Open World', 'Historical'],
    rating: 9.5,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    featured: true,
    tags: ['Cinematic', 'Samurai', 'Stunning Visuals'],
    createdAt: '2025-10-01T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z'
  },
  {
    id: 'g4',
    title: 'Black Myth: Wukong - Celestial Edition',
    synopsis: 'Rooted in Chinese mythology and Journey to the West, wield the legendary Ruyi Jingu Bang and unravel ancient mythical truths.',
    posterUrl: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1600&q=80',
    releaseDate: 'Available Now',
    developer: 'Game Science',
    publisher: 'Game Science',
    platforms: ['PC', 'PS5', 'Xbox Series X'],
    genres: ['Action RPG', 'Mythology', 'Souls-like'],
    rating: 9.3,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    featured: false,
    tags: ['Unreal Engine 5', 'Boss Battles', 'Mythology'],
    createdAt: '2025-08-20T00:00:00Z',
    updatedAt: '2026-01-20T00:00:00Z'
  }
];

export const INITIAL_SERIES: Series[] = [
  {
    id: 's1',
    title: 'Arcane: Legends of Zaun & Piltover',
    synopsis: 'Amid the burgeoning tension between the utopian city of Piltover and the underground city of Zaun, sisters Vi and Jinx find themselves on opposing sides of a catastrophic war.',
    posterUrl: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2024,
    totalSeasons: 2,
    totalEpisodes: 18,
    genres: ['Animation', 'Action', 'Sci-Fi', 'Fantasy'],
    creator: 'Christian Linke & Alex Yee',
    cast: ['Hailee Steinfeld', 'Ella Purnell', 'Kevin Alejandro', 'Katie Leung'],
    rating: 9.7,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    status: 'Completed',
    network: 'Netflix / Riot Games',
    featured: true,
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2026-02-10T00:00:00Z'
  },
  {
    id: 's2',
    title: 'The Last of Us: Season 2',
    synopsis: 'Five years after their dangerous journey across post-pandemic America, Joel and Ellie face violent repercussions from their past choices in Seattle.',
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2025,
    totalSeasons: 2,
    totalEpisodes: 16,
    genres: ['Drama', 'Action', 'Post-Apocalyptic', 'Horror'],
    creator: 'Craig Mazin & Neil Druckmann',
    cast: ['Pedro Pascal', 'Bella Ramsey', 'Kaitlyn Dever', 'Catherine O’Hara'],
    rating: 9.4,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    status: 'Ongoing',
    network: 'HBO Max',
    featured: true,
    createdAt: '2025-07-15T00:00:00Z',
    updatedAt: '2026-02-12T00:00:00Z'
  },
  {
    id: 's3',
    title: 'Severance: Level Two',
    synopsis: 'Mark Scout leads a team at Lumon Industries whose employees have had their memories surgically divided between their work and personal lives.',
    posterUrl: 'https://images.unsplash.com/photo-1509281373149-e957c6296406?auto=format&fit=crop&w=800&q=80',
    backdropUrl: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=1600&q=80',
    releaseYear: 2025,
    totalSeasons: 2,
    totalEpisodes: 19,
    genres: ['Mystery', 'Sci-Fi', 'Thriller'],
    creator: 'Dan Erickson',
    cast: ['Adam Scott', 'Patricia Arquette', 'John Turturro', 'Christopher Walken'],
    rating: 9.2,
    trailerUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    status: 'Ongoing',
    network: 'Apple TV+',
    featured: false,
    createdAt: '2025-05-10T00:00:00Z',
    updatedAt: '2026-01-30T00:00:00Z'
  }
];

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'a1',
    title: 'The Cinematic Revolution: How Unreal Engine 5 is Unifying Hollywood & Gaming',
    slug: 'cinematic-revolution-unreal-engine-5',
    excerpt: 'Virtual production volumes, real-time lumen illumination, and nanite geometry are tearing down the wall between interactive gaming and high-budget filmmaking.',
    content: `## A Converging Horizon
Film sets are no longer merely green screens and post-production rendering farms. Today, directors like Denis Villeneuve and Matt Reeves are utilizing real-time game engines directly on sound stages.

### Key Breakthroughs
1. **Lumen Dynamic Global Illumination**: Lighting bounces off physical actors and virtual worlds simultaneously.
2. **Nanite Virtualized Geometry**: Billions of polygons imported straight from ZBrush sculpts without losing fidelity.
3. **Motion Capture Fidelity**: Real-time facial rigs giving directors instant feedback on emotional performances.

As games become more cinematic and movies become more interactive, portals like **EDIXIAL** sit at the epicenter of this modern artistic renaissance.`,
    category: 'Exclusive',
    relatedType: 'movie',
    coverUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    author: {
      name: 'Elena Rostova',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      role: 'Chief Gaming & Cinema Critic',
      email: 'obscuramovie99@gmail.com'
    },
    publishedAt: '2026-02-28T14:30:00Z',
    readTime: '5 min read',
    tags: ['Tech', 'VFX', 'Unreal Engine', 'Cinema', 'Gaming'],
    featured: true,
    views: 34200,
    createdAt: '2026-02-28T14:30:00Z',
    updatedAt: '2026-02-28T14:30:00Z'
  },
  {
    id: 'a2',
    title: 'Top 10 Most Anticipated Next-Gen RPGs of 2026',
    slug: 'top-10-anticipated-rpgs-2026',
    excerpt: 'From massive dark fantasy epics to sprawling cyberpunk open worlds, here is the definitive breakdown of what every gamer must play this year.',
    content: `From revolutionary branching quest systems to AI-driven companion behaviors, 2026 is shaping up to be one of the greatest golden ages for role-playing games. Check our full interactive guide in the Games section of EDIXIAL!`,
    category: 'Feature',
    relatedType: 'game',
    coverUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80',
    author: {
      name: 'Marcus Vance',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      role: 'Senior Editor'
    },
    publishedAt: '2026-02-25T10:00:00Z',
    readTime: '6 min read',
    tags: ['RPGs', 'Gaming', 'Guide', '2026 Releases'],
    featured: true,
    views: 45800,
    createdAt: '2026-02-25T10:00:00Z',
    updatedAt: '2026-02-25T10:00:00Z'
  }
];

export const INITIAL_ADMINS: AdminUser[] = [
  {
    uid: 'owner-root',
    email: OWNER_EMAIL,
    displayName: 'EDIXIAL Primary Owner',
    photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    role: 'owner',
    addedAt: '2026-01-01T00:00:00Z',
    status: 'active'
  }
];
